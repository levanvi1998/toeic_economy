#pragma once
#include <gst/gst.h>
#include <string>

/**
 * VideoRecorder - Creates a GStreamer bin for recording H264 video to MP4 files
 */
class VideoRecorder {
public:
    static GstElement* createRecordBin(const std::string& stream_id, 
                                        const std::string& output_dir);
};
