#pragma once
#include <gst/gst.h>
#include <string>
#include <mutex>

/**
 * Utils - General utility functions
 * Note: Most GStreamer helpers moved to GstHelper class
 */
class Utils {
public:
    static void log(const std::string& msg);
    
    static void attachBusWatch(GstElement* pipeline, const std::string& stream_id);

private:
    static gboolean busCallback(GstBus* bus, GstMessage* msg, gpointer data);
};
