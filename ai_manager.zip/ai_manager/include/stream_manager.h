#pragma once
#include <string>
#include <unordered_map>
#include <thread>
#include <atomic>
#include <mutex>
#include <gst/gst.h>

/**
 * StreamManager - Manages multiple RTMP streams with auto-reconnect
 */
class StreamManager {
public:
    StreamManager() = default;
    ~StreamManager();
    
    // Configuration
    void setReconnectInterval(int ms) { reconnect_interval_ms_ = ms; }
    void setMaxReconnectAttempts(int n) { max_reconnect_attempts_ = n; }  // 0 = unlimited
    
    // Stream management
    bool addStream(GstElement* main_pipeline, const std::string& id, 
                   const std::string& url, const std::string& output_dir);
    bool removeStream(const std::string& id);
    bool restartStream(const std::string& id);
    void stop();
    
    size_t getStreamCount() const { return streams_.size(); }
    
    // Error handling - call this when stream error detected
    void onStreamError(const std::string& id);
    
    // Start reconnect background thread
    void startReconnectThread();

private:
    struct StreamInfo {
        GstElement* source = nullptr;
        std::string url;
        std::string output_dir;
        int reconnect_attempts = 0;
        bool reconnecting = false;
    };
    
    std::unordered_map<std::string, StreamInfo> streams_;
    GstElement* main_pipeline_ = nullptr;
    
    // Reconnect settings
    int reconnect_interval_ms_ = 5000;
    int max_reconnect_attempts_ = 0;  // 0 = unlimited
    
    // Reconnect thread
    std::thread reconnect_thread_;
    std::atomic<bool> running_{true};
    std::mutex mutex_;
    
    void reconnectLoop();
    bool doReconnect(const std::string& id);
};
