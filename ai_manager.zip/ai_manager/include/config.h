#pragma once
#include <string>
#include <vector>
#include <fstream>

/**
 * Stream configuration
 */
struct StreamConfig {
    std::string id;
    std::string url;
    bool enabled = true;
};

/**
 * Application configuration loaded from JSON
 */
struct AppConfig {
    // AI Engine settings
    std::string infer_config_path;
    int max_streams = 4;
    int infer_width = 640;
    int infer_height = 640;
    
    // Output settings  
    std::string output_dir;
    int segment_duration_sec = 10;
    
    // Stream settings
    std::vector<StreamConfig> streams;
    int reconnect_interval_ms = 5000;
    int max_reconnect_attempts = 0;  // 0 = unlimited
    
    // Logging
    int gst_debug_level = 2;  // GST_LEVEL_WARNING
    
    // Load from JSON file
    static AppConfig load(const std::string& path);
    
    // Save to JSON file
    void save(const std::string& path) const;
};
