#pragma once
#include <string>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <atomic>
#include <fstream>
#include <cstdint>
#include <unordered_map>

/**
 * Detection object structure
 */
struct Detection {
    int class_id;
    float confidence;
    float x, y, w, h;
};

/**
 * Frame metadata structure
 */
struct FrameMetadata {
    std::string stream_id;
    uint64_t pts;
    uint64_t timestamp;  // Unix timestamp in ms
    std::vector<Detection> detections;
};

/**
 * MetadataWriter - Background worker for writing detection metadata to files
 * Uses a queue-based approach for async writing
 */
class MetadataWriter {
public:
    static MetadataWriter& instance();
    
    // Start/stop worker thread
    void start(const std::string& output_dir);
    void stop();
    
    // Queue metadata for writing
    void push(const FrameMetadata& meta);
    
    // Get current file path for a stream
    std::string getCurrentFilePath(const std::string& stream_id) const;

private:
    MetadataWriter() = default;
    ~MetadataWriter();
    
    MetadataWriter(const MetadataWriter&) = delete;
    MetadataWriter& operator=(const MetadataWriter&) = delete;
    
    void workerLoop();
    void writeMetadata(const FrameMetadata& meta);
    void rotateFileIfNeeded(const std::string& stream_id);
    std::string generateFilePath(const std::string& stream_id);
    
    std::string output_dir_;
    std::atomic<bool> running_{false};
    std::thread worker_thread_;
    
    std::queue<FrameMetadata> queue_;
    std::mutex queue_mutex_;
    std::condition_variable queue_cv_;
    
    // File management per stream
    struct StreamFile {
        std::ofstream file;
        std::string path;
        uint64_t start_time = 0;
        int file_index = 0;
    };
    std::unordered_map<std::string, StreamFile> stream_files_;
    std::mutex files_mutex_;
    
    static constexpr uint64_t FILE_ROTATION_INTERVAL_MS = 10000;  // 10 seconds, same as video
};
