#pragma once
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <string>
#include <cstdint>
#include <atomic>
#include <mutex>
#include <unordered_map>

/**
 * AIEngine - Manages DeepStream inference pipeline
 * Refactored to use instance-based approach instead of static globals
 */
class AIEngine {
public:
    static AIEngine& instance();
    
    // Initialize the AI pipeline
    void init(GstElement* main_pipeline, uint32_t max_batch, 
              const std::string& infer_config_path,
              const std::string& metadata_output_dir);
    
    // Request a sink pad for a new stream
    GstPad* requestSinkPad(const std::string& stream_id);
    
    // Release stream resources
    void releaseStream(const std::string& stream_id);
    
    // Stream ID mapping
    void registerStream(int pad_index, const std::string& stream_id);
    void unregisterStream(int pad_index);
    std::string getStreamId(int pad_index);
    int getPadIndex(const std::string& stream_id);
    
    // Shutdown
    void shutdown();

private:
    AIEngine() = default;
    ~AIEngine() = default;
    
    AIEngine(const AIEngine&) = delete;
    AIEngine& operator=(const AIEngine&) = delete;
    
    // GStreamer callback
    static GstFlowReturn onNewSample(GstAppSink* sink, gpointer user_data);
    void processBuffer(GstBuffer* buffer);
    
    // Pipeline elements
    GstElement* streammux_ = nullptr;
    GstElement* infer_ = nullptr;
    GstElement* sink_ = nullptr;
    
    std::atomic<int> pad_index_{0};
    
    // Stream mapping
    std::mutex map_mutex_;
    std::unordered_map<int, std::string> pad_to_stream_;
    std::unordered_map<std::string, int> stream_to_pad_;
};
