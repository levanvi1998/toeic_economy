#pragma once
#include <gst/gst.h>
#include <string>

/**
 * GStreamer helper functions - common operations used throughout the pipeline
 */
class GstHelper {
public:
    // Element creation & management
    static GstElement* createElement(const std::string& factory, const std::string& name = "");
    static void addAndSync(GstElement* pipeline, GstElement* element);
    static void addAndSyncMany(GstElement* pipeline, std::initializer_list<GstElement*> elements);
    
    // Pad operations
    static bool linkPads(GstPad* src, GstPad* sink);
    static GstPad* getStaticPad(GstElement* element, const std::string& name);
    static GstPad* requestPad(GstElement* element, const std::string& template_name);
    
    // Caps utilities
    static bool isVideoCaps(GstCaps* caps);
    static bool isAudioCaps(GstCaps* caps);
    static bool isH264Caps(GstCaps* caps);
    static bool isContainerCaps(GstCaps* caps);
    static std::string getCapsString(GstCaps* caps);
    
    // Common element patterns
    static GstElement* createQueue(const std::string& name, int max_buffers = 200, bool leaky = false);
    static GstElement* createFakesink();
    static GstElement* createCapsFilter(const std::string& name, const std::string& caps_str);
    
    // Linking helpers
    static void linkToFakesink(GstElement* pipeline, GstPad* pad);
};
