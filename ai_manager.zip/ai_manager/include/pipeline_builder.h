#pragma once
#include <gst/gst.h>
#include <string>

/**
 * PipelineBuilder - Builds GStreamer pipeline for a stream
 * Handles RTMP source, demuxing, decoding, and routing to AI/record branches
 */
class PipelineBuilder {
public:
    static PipelineBuilder& instance();
    
    // Build source pipeline for a stream
    GstElement* build(GstElement* main_pipeline, const std::string& stream_id,
                      const std::string& rtmp_url, const std::string& output_dir);
    
private:
    PipelineBuilder() = default;
    
    PipelineBuilder(const PipelineBuilder&) = delete;
    PipelineBuilder& operator=(const PipelineBuilder&) = delete;
    
    // Main pipeline reference
    GstElement* main_pipeline_ = nullptr;
    std::string output_dir_ = "/workspace/recordings";
    
    // Video branch builders
    void buildVideoBranch(GstPad* src_pad, const std::string& stream_id);
    void buildH264Branch(GstPad* src_pad, const std::string& stream_id);
    void buildRawVideoBranch(GstPad* src_pad, const std::string& stream_id);
    
    // Common sub-pipeline creation
    void createAIBranch(GstElement* tee, const std::string& stream_id, bool need_decode);
    void createRecordBranch(GstElement* tee, const std::string& stream_id, bool is_h264);
    
    // Pad callbacks
    static void onSourcePadAdded(GstElement* src, GstPad* pad, gpointer user_data);
    static void onDemuxPadAdded(GstElement* demux, GstPad* pad, gpointer user_data);
    static void onDemuxCapsChanged(GstPad* pad, GParamSpec* pspec, gpointer user_data);
    
    // Helper to handle pad based on caps
    void handlePad(GstPad* pad, const std::string& stream_id);
};
