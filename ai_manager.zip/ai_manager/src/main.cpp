#include <gst/gst.h>
#include <csignal>
#include <iostream>
#include "stream_manager.h"
#include "ai_engine.h"
#include "config.h"

static GMainLoop *main_loop = nullptr;
static StreamManager* g_stream_manager = nullptr;

static void signalHandler(int sig)
{
    if (sig == SIGINT || sig == SIGTERM)
    {
        std::cout << "\n[SIGNAL] Received signal " << sig << ", shutting down..." << std::endl;
        if (main_loop)
        {
            g_main_loop_quit(main_loop);
        }
    }
}

// Bus callback for error handling
static gboolean busCallback(GstBus*, GstMessage* msg, gpointer) {
    switch (GST_MESSAGE_TYPE(msg)) {
    case GST_MESSAGE_ERROR: {
        GError* err = nullptr;
        gchar* dbg = nullptr;
        gst_message_parse_error(msg, &err, &dbg);
        
        std::cerr << "[ERROR] " << GST_OBJECT_NAME(msg->src) << ": "
                  << (err ? err->message : "unknown") << std::endl;
        
        // Try to find stream_id from element name
        std::string name = GST_OBJECT_NAME(msg->src);
        size_t pos = name.find("_cam");
        if (pos != std::string::npos && g_stream_manager) {
            std::string stream_id = name.substr(pos + 1);
            pos = stream_id.find('_');
            if (pos != std::string::npos) {
                stream_id = stream_id.substr(0, pos);
            }
            g_stream_manager->onStreamError(stream_id);
        }
        
        if (dbg) g_free(dbg);
        if (err) g_error_free(err);
        break;
    }
    case GST_MESSAGE_EOS:
        std::cout << "[EOS] End of stream" << std::endl;
        break;
    default:
        break;
    }
    return TRUE;
}

int main(int argc, char *argv[])
{
    // Setup signal handlers
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    // Load configuration
    std::string config_path = "/workspace/ai_manager/config.json";
    if (argc > 1) {
        config_path = argv[1];
    }
    
    AppConfig config = AppConfig::load(config_path);
    
    // Initialize GStreamer
    gst_debug_set_default_threshold(static_cast<GstDebugLevel>(config.gst_debug_level));
    gst_init(&argc, &argv);

    // Create main pipeline (required as container for all elements)
    GstElement *main_pipeline = gst_pipeline_new("main");
    
    // Attach bus watch for error handling
    GstBus* bus = gst_element_get_bus(main_pipeline);
    gst_bus_add_watch(bus, busCallback, nullptr);
    gst_object_unref(bus);

    // Initialize AI Engine
    AIEngine::instance().init(main_pipeline, config.max_streams, 
                              config.infer_config_path, config.output_dir);

    // Create stream manager
    StreamManager mgr;
    g_stream_manager = &mgr;
    mgr.setReconnectInterval(config.reconnect_interval_ms);
    mgr.setMaxReconnectAttempts(config.max_reconnect_attempts);
    
    // Add enabled streams from config
    int added = 0;
    for (const auto& stream : config.streams) {
        if (stream.enabled) {
            if (mgr.addStream(main_pipeline, stream.id, stream.url, config.output_dir)) {
                added++;
            }
        }
    }
    
    if (added == 0) {
        std::cerr << "[ERROR] No streams configured. Check config.json" << std::endl;
        gst_object_unref(main_pipeline);
        return 1;
    }
    
    std::cout << "[INFO] Added " << added << " stream(s)" << std::endl;
    
    // Start reconnect thread
    mgr.startReconnectThread();

    // Start pipeline
    gst_element_set_state(main_pipeline, GST_STATE_PLAYING);

    // Run main loop
    main_loop = g_main_loop_new(nullptr, FALSE);
    std::cout << "[INFO] Pipeline running. Press Ctrl+C to stop." << std::endl;
    g_main_loop_run(main_loop);

    // Cleanup
    std::cout << "[INFO] Stopping..." << std::endl;
    g_stream_manager = nullptr;
    mgr.stop();
    AIEngine::instance().shutdown();

    gst_element_set_state(main_pipeline, GST_STATE_NULL);
    gst_object_unref(main_pipeline);
    g_main_loop_unref(main_loop);
    gst_deinit();

    std::cout << "[INFO] Shutdown complete." << std::endl;
    return 0;
}
