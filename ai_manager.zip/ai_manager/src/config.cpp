#include "config.h"
#include <iostream>
#include <sstream>
#include <regex>
#include <fstream>

// Simple JSON parser (no external dependencies)
namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

std::string extractString(const std::string& json, const std::string& key) {
    std::regex re("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
    std::smatch match;
    if (std::regex_search(json, match, re)) {
        return match[1].str();
    }
    return "";
}

int extractInt(const std::string& json, const std::string& key, int defaultVal) {
    std::regex re("\"" + key + "\"\\s*:\\s*(-?\\d+)");
    std::smatch match;
    if (std::regex_search(json, match, re)) {
        return std::stoi(match[1].str());
    }
    return defaultVal;
}

bool extractBool(const std::string& json, const std::string& key, bool defaultVal) {
    std::regex re("\"" + key + "\"\\s*:\\s*(true|false)");
    std::smatch match;
    if (std::regex_search(json, match, re)) {
        return match[1].str() == "true";
    }
    return defaultVal;
}

std::vector<StreamConfig> extractStreams(const std::string& json) {
    std::vector<StreamConfig> streams;
    
    // Find streams array
    std::regex arrayRe("\"streams\"\\s*:\\s*\\[([^\\]]+)\\]");
    std::smatch arrayMatch;
    if (!std::regex_search(json, arrayMatch, arrayRe)) {
        return streams;
    }
    
    std::string arrayContent = arrayMatch[1].str();
    
    // Find each stream object
    std::regex objRe("\\{([^}]+)\\}");
    auto begin = std::sregex_iterator(arrayContent.begin(), arrayContent.end(), objRe);
    auto end = std::sregex_iterator();
    
    for (auto it = begin; it != end; ++it) {
        std::string obj = (*it)[1].str();
        StreamConfig sc;
        sc.id = extractString(obj, "id");
        sc.url = extractString(obj, "url");
        sc.enabled = extractBool(obj, "enabled", true);
        
        if (!sc.id.empty() && !sc.url.empty()) {
            streams.push_back(sc);
        }
    }
    
    return streams;
}

} // anonymous namespace

AppConfig AppConfig::load(const std::string& path) {
    AppConfig config;
    
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "[Config] Cannot open config file: " << path << std::endl;
        std::cerr << "[Config] Using default configuration" << std::endl;
        return config;
    }
    
    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string json = buffer.str();
    file.close();
    
    // Parse values
    config.infer_config_path = extractString(json, "infer_config_path");
    config.max_streams = extractInt(json, "max_streams", 4);
    config.infer_width = extractInt(json, "infer_width", 640);
    config.infer_height = extractInt(json, "infer_height", 640);
    
    config.output_dir = extractString(json, "output_dir");
    config.segment_duration_sec = extractInt(json, "segment_duration_sec", 10);
    
    config.reconnect_interval_ms = extractInt(json, "reconnect_interval_ms", 5000);
    config.max_reconnect_attempts = extractInt(json, "max_reconnect_attempts", 0);
    
    config.gst_debug_level = extractInt(json, "gst_debug_level", 2);
    
    config.streams = extractStreams(json);
    
    std::cout << "[Config] Loaded from: " << path << std::endl;
    std::cout << "[Config] Found " << config.streams.size() << " stream(s)" << std::endl;
    
    return config;
}

void AppConfig::save(const std::string& path) const {
    std::ofstream file(path);
    if (!file.is_open()) {
        std::cerr << "[Config] Cannot write config file: " << path << std::endl;
        return;
    }
    
    file << "{\n";
    file << "  \"infer_config_path\": \"" << infer_config_path << "\",\n";
    file << "  \"max_streams\": " << max_streams << ",\n";
    file << "  \"infer_width\": " << infer_width << ",\n";
    file << "  \"infer_height\": " << infer_height << ",\n";
    file << "  \"output_dir\": \"" << output_dir << "\",\n";
    file << "  \"segment_duration_sec\": " << segment_duration_sec << ",\n";
    file << "  \"reconnect_interval_ms\": " << reconnect_interval_ms << ",\n";
    file << "  \"max_reconnect_attempts\": " << max_reconnect_attempts << ",\n";
    file << "  \"gst_debug_level\": " << gst_debug_level << ",\n";
    file << "  \"streams\": [\n";
    
    for (size_t i = 0; i < streams.size(); ++i) {
        file << "    {\n";
        file << "      \"id\": \"" << streams[i].id << "\",\n";
        file << "      \"url\": \"" << streams[i].url << "\",\n";
        file << "      \"enabled\": " << (streams[i].enabled ? "true" : "false") << "\n";
        file << "    }" << (i < streams.size() - 1 ? "," : "") << "\n";
    }
    
    file << "  ]\n";
    file << "}\n";
    
    file.close();
    std::cout << "[Config] Saved to: " << path << std::endl;
}
