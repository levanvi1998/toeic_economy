#include "video_recorder.h"
#include "gst_helper.h"
#include <iostream>

GstElement *VideoRecorder::createRecordBin(const std::string &stream_id,
                                           const std::string &output_dir)
{
    GstElement *bin = gst_bin_new(("record_bin_" + stream_id).c_str());

    GstElement *queue = GstHelper::createElement("queue");
    GstElement *parse = GstHelper::createElement("h264parse");
    GstElement *mux = GstHelper::createElement("splitmuxsink");
    GstElement *qtmux = GstHelper::createElement("qtmux");

    std::string location = output_dir + "/" + stream_id + "_%05d.mp4";

    g_object_set(mux,
                 "location", location.c_str(),
                 "max-size-time", (guint64)10 * GST_SECOND,
                 "muxer", qtmux,
                 NULL);

    gst_bin_add_many(GST_BIN(bin), queue, parse, mux, NULL);
    gst_element_link(queue, parse);
    gst_element_link(parse, mux);

    // Create ghost pad
    GstPad *sink_pad = gst_element_get_static_pad(queue, "sink");
    GstPad *ghost = gst_ghost_pad_new("sink", sink_pad);
    gst_element_add_pad(bin, ghost);
    gst_object_unref(sink_pad);

    std::cout << "[VideoRecorder] Created record bin for: " << stream_id
              << " -> " << location << std::endl;

    return bin;
}
