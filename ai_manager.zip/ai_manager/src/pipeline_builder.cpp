#include "pipeline_builder.h"
#include "gst_helper.h"
#include "ai_engine.h"
#include "video_recorder.h"
#include <iostream>
#include <cstring>

PipelineBuilder &PipelineBuilder::instance()
{
    static PipelineBuilder inst;
    return inst;
}

GstElement *PipelineBuilder::build(GstElement *main_pipeline, const std::string &stream_id,
                                   const std::string &rtmp_url, const std::string &output_dir)
{
    main_pipeline_ = main_pipeline;
    output_dir_ = output_dir;

    // Store stream_id for callbacks
    char *stream_id_copy = strdup(stream_id.c_str());

    // Create source
    GstElement *src = GstHelper::createElement("urisourcebin", "src_" + stream_id);
    g_object_set(src, "uri", rtmp_url.c_str(), NULL);

    // Create queue to buffer after urisourcebin
    GstElement *queue = GstHelper::createQueue("queue_src_" + stream_id, 200);
    g_object_set(queue,
                 "max-size-bytes", 10485760,
                 "max-size-time", (guint64)5000000000,
                 NULL);

    // Create flvdemux for RTMP streams
    GstElement *demux = GstHelper::createElement("flvdemux", "flvdemux_" + stream_id);

    // Add all to pipeline
    gst_bin_add_many(GST_BIN(main_pipeline), src, queue, demux, NULL);

    // Link queue -> demux
    if (!gst_element_link(queue, demux))
    {
        std::cerr << "[PipelineBuilder] Failed to link queue -> flvdemux" << std::endl;
    }

    // Store references for callbacks
    g_object_set_data(G_OBJECT(src), "target-queue", queue);
    g_object_set_data_full(G_OBJECT(src), "stream-id", stream_id_copy, g_free);
    g_object_set_data_full(G_OBJECT(demux), "stream-id", strdup(stream_id.c_str()), g_free);

    // Connect callbacks
    g_signal_connect(src, "pad-added", G_CALLBACK(onSourcePadAdded), this);
    g_signal_connect(demux, "pad-added", G_CALLBACK(onDemuxPadAdded), this);

    return src;
}

void PipelineBuilder::onSourcePadAdded(GstElement *src, GstPad *pad, gpointer user_data)
{
    PipelineBuilder *self = static_cast<PipelineBuilder *>(user_data);
    char *stream_id = (char *)g_object_get_data(G_OBJECT(src), "stream-id");

    std::cout << "[PipelineBuilder] Source pad added for stream: " << stream_id << std::endl;

    GstElement *queue = (GstElement *)g_object_get_data(G_OBJECT(src), "target-queue");
    if (!queue)
    {
        std::cerr << "[PipelineBuilder] No target queue found!" << std::endl;
        return;
    }

    GstPad *queue_sink = GstHelper::getStaticPad(queue, "sink");
    if (!GstHelper::linkPads(pad, queue_sink))
    {
        std::cerr << "[PipelineBuilder] Failed to link source pad to queue" << std::endl;
    }
    else
    {
        std::cout << "[PipelineBuilder] Linked source pad to queue for: " << stream_id << std::endl;
    }
    gst_object_unref(queue_sink);
}

void PipelineBuilder::onDemuxPadAdded(GstElement *demux, GstPad *pad, gpointer user_data)
{
    PipelineBuilder *self = static_cast<PipelineBuilder *>(user_data);
    char *stream_id = (char *)g_object_get_data(G_OBJECT(demux), "stream-id");

    gchar *pad_name = gst_pad_get_name(pad);
    std::cout << "[PipelineBuilder] Demux pad added: " << pad_name << " for stream: " << stream_id << std::endl;
    g_free(pad_name);

    GstCaps *caps = gst_pad_get_current_caps(pad);
    if (!caps)
    {
        caps = gst_pad_query_caps(pad, NULL);
    }

    if (caps)
    {
        self->handlePad(pad, stream_id);
        gst_caps_unref(caps);
    }
    else
    {
        // Wait for caps
        g_object_set_data_full(G_OBJECT(pad), "stream-id", strdup(stream_id), g_free);
        g_signal_connect(pad, "notify::caps", G_CALLBACK(onDemuxCapsChanged), self);
    }
}

void PipelineBuilder::onDemuxCapsChanged(GstPad *pad, GParamSpec *pspec, gpointer user_data)
{
    PipelineBuilder *self = static_cast<PipelineBuilder *>(user_data);
    char *stream_id = (char *)g_object_get_data(G_OBJECT(pad), "stream-id");

    GstCaps *caps = gst_pad_get_current_caps(pad);
    if (!caps)
        return;

    self->handlePad(pad, stream_id);
    gst_caps_unref(caps);
}

void PipelineBuilder::handlePad(GstPad *pad, const std::string &stream_id)
{
    GstCaps *caps = gst_pad_get_current_caps(pad);
    if (!caps)
    {
        caps = gst_pad_query_caps(pad, NULL);
    }
    if (!caps)
        return;

    std::string caps_str = GstHelper::getCapsString(caps);
    std::cout << "[PipelineBuilder] Handling pad with caps: " << caps_str << std::endl;

    // Audio -> fakesink
    if (GstHelper::isAudioCaps(caps))
    {
        GstHelper::linkToFakesink(main_pipeline_, pad);
        std::cout << "[PipelineBuilder] Linked audio to fakesink" << std::endl;
        gst_caps_unref(caps);
        return;
    }

    // Video
    if (GstHelper::isVideoCaps(caps) || GstHelper::isH264Caps(caps))
    {
        buildVideoBranch(pad, stream_id);
    }

    gst_caps_unref(caps);
}

void PipelineBuilder::buildVideoBranch(GstPad *src_pad, const std::string &stream_id)
{
    GstCaps *caps = gst_pad_get_current_caps(src_pad);
    bool is_h264 = caps && GstHelper::isH264Caps(caps);
    if (caps)
        gst_caps_unref(caps);

    std::cout << "[PipelineBuilder] Building video branch for: " << stream_id
              << " (H264: " << (is_h264 ? "yes" : "no") << ")" << std::endl;

    // Input queue
    GstElement *q_in = GstHelper::createQueue("q_in_" + stream_id, 200);
    GstHelper::addAndSync(main_pipeline_, q_in);

    // Link src_pad -> q_in
    GstPad *q_in_sink = GstHelper::getStaticPad(q_in, "sink");
    GstHelper::linkPads(src_pad, q_in_sink);
    gst_object_unref(q_in_sink);

    // Tee for branching
    GstElement *tee = GstHelper::createElement("tee", "tee_" + stream_id);
    GstHelper::addAndSync(main_pipeline_, tee);
    gst_element_link(q_in, tee);

    // Create AI and Record branches
    createAIBranch(tee, stream_id, is_h264);
    createRecordBranch(tee, stream_id, is_h264);

    std::cout << "[PipelineBuilder] Video branch built for: " << stream_id << std::endl;
}

void PipelineBuilder::createAIBranch(GstElement *tee, const std::string &stream_id, bool is_h264)
{
    // Queue for AI branch (leaky)
    GstElement *q_ai = GstHelper::createQueue("q_ai_" + stream_id, 1, true);
    GstHelper::addAndSync(main_pipeline_, q_ai);

    // Link tee -> q_ai
    GstPad *tee_src = GstHelper::requestPad(tee, "src_%u");
    GstPad *q_ai_sink = GstHelper::getStaticPad(q_ai, "sink");
    GstHelper::linkPads(tee_src, q_ai_sink);
    gst_object_unref(q_ai_sink);

    GstElement *last_elem = q_ai;

    if (is_h264)
    {
        // H264: parse -> decode -> convert -> capsfilter
        GstElement *parse = GstHelper::createElement("h264parse", "h264parse_ai_" + stream_id);
        GstElement *decoder = GstHelper::createElement("nvv4l2decoder", "decoder_" + stream_id);
        GstElement *conv = GstHelper::createElement("nvvideoconvert", "conv_" + stream_id);
        GstElement *capsf = GstHelper::createCapsFilter("capsf_" + stream_id, "video/x-raw(memory:NVMM),format=NV12");

        GstHelper::addAndSyncMany(main_pipeline_, {parse, decoder, conv, capsf});
        gst_element_link_many(q_ai, parse, decoder, conv, capsf, NULL);
        last_elem = capsf;
    }
    else
    {
        // Raw video: convert -> capsfilter
        GstElement *conv = GstHelper::createElement("nvvideoconvert", "conv_" + stream_id);
        GstElement *capsf = GstHelper::createCapsFilter("capsf_" + stream_id, "video/x-raw(memory:NVMM),format=NV12");

        GstHelper::addAndSyncMany(main_pipeline_, {conv, capsf});
        gst_element_link_many(q_ai, conv, capsf, NULL);
        last_elem = capsf;
    }

    // Link to AI Engine
    GstPad *capsf_src = GstHelper::getStaticPad(last_elem, "src");
    GstPad *mux_sink = AIEngine::instance().requestSinkPad(stream_id);
    GstHelper::linkPads(capsf_src, mux_sink);
    gst_object_unref(capsf_src);
    gst_object_unref(mux_sink);
}

void PipelineBuilder::createRecordBranch(GstElement *tee, const std::string &stream_id, bool is_h264)
{
    // Queue for record branch
    GstElement *q_rec = GstHelper::createQueue("q_rec_" + stream_id, 200);
    GstHelper::addAndSync(main_pipeline_, q_rec);

    // Link tee -> q_rec
    GstPad *tee_src = GstHelper::requestPad(tee, "src_%u");
    GstPad *q_rec_sink = GstHelper::getStaticPad(q_rec, "sink");
    GstHelper::linkPads(tee_src, q_rec_sink);
    gst_object_unref(q_rec_sink);

    GstElement *last_elem = q_rec;

    if (is_h264)
    {
        // H264: just parse
        GstElement *parse = GstHelper::createElement("h264parse", "h264parse_rec_" + stream_id);
        GstHelper::addAndSync(main_pipeline_, parse);
        gst_element_link(q_rec, parse);
        last_elem = parse;
    }
    else
    {
        // Raw: encode -> parse
        GstElement *encoder = GstHelper::createElement("nvv4l2h264enc", "encoder_" + stream_id);
        g_object_set(encoder,
                     "iframeinterval", 30,
                     "control-rate", 1,
                     "bitrate", 4000000,
                     "preset-level", 1,
                     "insert-sps-pps", 1,
                     NULL);

        GstElement *parse = GstHelper::createElement("h264parse", "h264parse_rec_" + stream_id);
        GstHelper::addAndSyncMany(main_pipeline_, {encoder, parse});
        gst_element_link_many(q_rec, encoder, parse, NULL);
        last_elem = parse;
    }

    // Record bin
    GstElement *rec = VideoRecorder::createRecordBin(stream_id, output_dir_);
    GstHelper::addAndSync(main_pipeline_, rec);
    gst_element_link(last_elem, rec);
}
