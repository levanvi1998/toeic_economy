#include "metadata_writer.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <filesystem>

namespace fs = std::filesystem;

MetadataWriter &MetadataWriter::instance()
{
    static MetadataWriter inst;
    return inst;
}

MetadataWriter::~MetadataWriter()
{
    stop();
}

void MetadataWriter::start(const std::string &output_dir)
{
    if (running_)
        return;

    output_dir_ = output_dir;

    // Create output directory if not exists
    fs::create_directories(output_dir_);

    running_ = true;
    worker_thread_ = std::thread(&MetadataWriter::workerLoop, this);

    std::cout << "[MetadataWriter] Started, output dir: " << output_dir_ << std::endl;
}

void MetadataWriter::stop()
{
    if (!running_)
        return;

    running_ = false;
    queue_cv_.notify_all();

    if (worker_thread_.joinable())
    {
        worker_thread_.join();
    }

    // Close all files
    std::lock_guard<std::mutex> lock(files_mutex_);
    for (auto &[id, sf] : stream_files_)
    {
        if (sf.file.is_open())
        {
            sf.file << "]\n"; // Close JSON array
            sf.file.close();
        }
    }
    stream_files_.clear();

    std::cout << "[MetadataWriter] Stopped" << std::endl;
}

void MetadataWriter::push(const FrameMetadata &meta)
{
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        queue_.push(meta);
    }
    queue_cv_.notify_one();
}

void MetadataWriter::workerLoop()
{
    while (running_)
    {
        FrameMetadata meta;

        {
            std::unique_lock<std::mutex> lock(queue_mutex_);
            queue_cv_.wait(lock, [this]
                           { return !queue_.empty() || !running_; });

            if (!running_ && queue_.empty())
                break;

            if (!queue_.empty())
            {
                meta = std::move(queue_.front());
                queue_.pop();
            }
            else
            {
                continue;
            }
        }

        writeMetadata(meta);
    }

    // Flush remaining items
    std::lock_guard<std::mutex> lock(queue_mutex_);
    while (!queue_.empty())
    {
        writeMetadata(queue_.front());
        queue_.pop();
    }
}

void MetadataWriter::rotateFileIfNeeded(const std::string &stream_id)
{
    std::lock_guard<std::mutex> lock(files_mutex_);

    auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
                   std::chrono::system_clock::now().time_since_epoch())
                   .count();

    auto it = stream_files_.find(stream_id);

    // Create new file if needed
    if (it == stream_files_.end() ||
        (now - it->second.start_time) >= FILE_ROTATION_INTERVAL_MS)
    {

        // Close old file
        if (it != stream_files_.end() && it->second.file.is_open())
        {
            it->second.file << "\n]\n";
            it->second.file.close();
        }

        // Create new file
        StreamFile sf;
        sf.start_time = now;
        sf.file_index = (it != stream_files_.end()) ? it->second.file_index + 1 : 0;
        sf.path = generateFilePath(stream_id);

        // Replace the index placeholder
        std::ostringstream idx_str;
        idx_str << std::setw(5) << std::setfill('0') << sf.file_index;
        size_t pos = sf.path.find("%05d");
        if (pos != std::string::npos)
        {
            sf.path.replace(pos, 4, idx_str.str());
        }

        sf.file.open(sf.path);
        if (sf.file.is_open())
        {
            sf.file << "[\n"; // Start JSON array
            std::cout << "[MetadataWriter] Created file: " << sf.path << std::endl;
        }

        stream_files_[stream_id] = std::move(sf);
    }
}

std::string MetadataWriter::generateFilePath(const std::string &stream_id)
{
    return output_dir_ + "/" + stream_id + "_%05d.json";
}

std::string MetadataWriter::getCurrentFilePath(const std::string &stream_id) const
{
    auto it = stream_files_.find(stream_id);
    return (it != stream_files_.end()) ? it->second.path : "";
}

void MetadataWriter::writeMetadata(const FrameMetadata &meta)
{
    rotateFileIfNeeded(meta.stream_id);

    std::lock_guard<std::mutex> lock(files_mutex_);
    auto it = stream_files_.find(meta.stream_id);
    if (it == stream_files_.end() || !it->second.file.is_open())
    {
        return;
    }

    auto &file = it->second.file;

    // Check if we need comma (not first entry)
    static std::unordered_map<std::string, bool> first_entry;
    if (first_entry.find(meta.stream_id) == first_entry.end())
    {
        first_entry[meta.stream_id] = true;
    }
    else
    {
        file << ",\n";
    }

    // Write JSON object
    file << "  {\n";
    file << "    \"stream_id\": \"" << meta.stream_id << "\",\n";
    file << "    \"pts\": " << meta.pts << ",\n";
    file << "    \"timestamp\": " << meta.timestamp << ",\n";
    file << "    \"detections\": [\n";

    for (size_t i = 0; i < meta.detections.size(); ++i)
    {
        const auto &det = meta.detections[i];
        file << "      {";
        file << "\"class_id\": " << det.class_id << ", ";
        file << "\"confidence\": " << std::fixed << std::setprecision(2) << det.confidence << ", ";
        file << "\"bbox\": ["
             << std::fixed << std::setprecision(1)
             << det.x << ", " << det.y << ", " << det.w << ", " << det.h << "]";
        file << "}";
        if (i < meta.detections.size() - 1)
            file << ",";
        file << "\n";
    }

    file << "    ]\n";
    file << "  }";

    file.flush();
}
