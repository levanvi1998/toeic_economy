#include "utils.h"
#include <iostream>
#include <mutex>

static std::mutex log_mutex;

void Utils::log(const std::string &msg)
{
    std::lock_guard<std::mutex> lock(log_mutex);
    std::cout << "[LOG] " << msg << std::endl;
}

gboolean Utils::busCallback(GstBus *, GstMessage *msg, gpointer data)
{
    auto *stream_id = static_cast<std::string *>(data);

    switch (GST_MESSAGE_TYPE(msg))
    {
    case GST_MESSAGE_ERROR:
    {
        GError *err = nullptr;
        gchar *dbg = nullptr;
        gst_message_parse_error(msg, &err, &dbg);

        std::cerr << "[ERROR] [" << *stream_id << "] from "
                  << GST_OBJECT_NAME(msg->src) << ": "
                  << (err ? err->message : "unknown") << std::endl;

        if (dbg)
        {
            std::cerr << "[DEBUG] " << dbg << std::endl;
            g_free(dbg);
        }
        if (err)
            g_error_free(err);
        break;
    }
    case GST_MESSAGE_EOS:
        std::cout << "[EOS] Stream: " << *stream_id << std::endl;
        break;
    case GST_MESSAGE_WARNING:
    {
        GError *err = nullptr;
        gchar *dbg = nullptr;
        gst_message_parse_warning(msg, &err, &dbg);

        std::cerr << "[WARNING] [" << *stream_id << "] "
                  << (err ? err->message : "unknown") << std::endl;

        if (dbg)
            g_free(dbg);
        if (err)
            g_error_free(err);
        break;
    }
    default:
        break;
    }
    return TRUE;
}

void Utils::attachBusWatch(GstElement *pipeline, const std::string &stream_id)
{
    GstBus *bus = gst_element_get_bus(pipeline);

    gst_bus_add_watch_full(
        bus,
        G_PRIORITY_DEFAULT,
        busCallback,
        new std::string(stream_id),
        [](gpointer data)
        {
            delete static_cast<std::string *>(data);
        });

    gst_object_unref(bus);
}
