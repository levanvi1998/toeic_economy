#include "stream_manager.h"
#include "pipeline_builder.h"
#include <iostream>
#include <chrono>

StreamManager::~StreamManager() {
    stop();
}

bool StreamManager::addStream(GstElement *main_pipeline, const std::string &id,
                              const std::string &url, const std::string &output_dir)
{
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (streams_.count(id))
    {
        std::cerr << "[StreamManager] Stream already exists: " << id << std::endl;
        return false;
    }

    main_pipeline_ = main_pipeline;

    GstElement *src = PipelineBuilder::instance().build(main_pipeline, id, url, output_dir);
    if (!src) {
        std::cerr << "[StreamManager] Failed to build stream: " << id << std::endl;
        return false;
    }
    
    gst_element_sync_state_with_parent(src);

    StreamInfo info;
    info.source = src;
    info.url = url;
    info.output_dir = output_dir;
    info.reconnect_attempts = 0;
    info.reconnecting = false;
    
    streams_[id] = info;

    std::cout << "[StreamManager] Added stream: " << id << " (" << url << ")" << std::endl;
    return true;
}

bool StreamManager::removeStream(const std::string &id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    
    auto it = streams_.find(id);
    if (it == streams_.end())
    {
        std::cerr << "[StreamManager] Stream not found: " << id << std::endl;
        return false;
    }

    if (it->second.source) {
        gst_element_set_state(it->second.source, GST_STATE_NULL);
        gst_bin_remove(GST_BIN(main_pipeline_), it->second.source);
    }

    streams_.erase(it);

    std::cout << "[StreamManager] Removed stream: " << id << std::endl;
    return true;
}

bool StreamManager::restartStream(const std::string &id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    return doReconnect(id);
}

bool StreamManager::doReconnect(const std::string& id)
{
    // Note: mutex should already be held
    auto it = streams_.find(id);
    if (it == streams_.end())
    {
        return false;
    }

    std::string url = it->second.url;
    std::string output_dir = it->second.output_dir;

    // Remove old source
    if (it->second.source) {
        gst_element_set_state(it->second.source, GST_STATE_NULL);
        gst_bin_remove(GST_BIN(main_pipeline_), it->second.source);
        it->second.source = nullptr;
    }

    // Create new source
    GstElement *new_src = PipelineBuilder::instance().build(main_pipeline_, id, url, output_dir);
    if (!new_src) {
        std::cerr << "[StreamManager] Reconnect failed for: " << id << std::endl;
        return false;
    }
    
    gst_element_sync_state_with_parent(new_src);

    it->second.source = new_src;
    it->second.reconnecting = false;
    it->second.reconnect_attempts = 0;

    std::cout << "[StreamManager] Reconnected stream: " << id << std::endl;
    return true;
}

void StreamManager::onStreamError(const std::string& id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    
    auto it = streams_.find(id);
    if (it == streams_.end()) return;
    
    if (!it->second.reconnecting) {
        it->second.reconnecting = true;
        std::cout << "[StreamManager] Stream error detected: " << id 
                  << ", will reconnect in " << reconnect_interval_ms_ << "ms" << std::endl;
    }
}

void StreamManager::reconnectLoop()
{
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_interval_ms_));
        
        if (!running_) break;
        
        std::lock_guard<std::mutex> lock(mutex_);
        
        for (auto& [id, info] : streams_) {
            if (!info.reconnecting) continue;
            
            // Check max attempts
            if (max_reconnect_attempts_ > 0 && 
                info.reconnect_attempts >= max_reconnect_attempts_) {
                std::cerr << "[StreamManager] Max reconnect attempts reached for: " << id << std::endl;
                info.reconnecting = false;
                continue;
            }
            
            info.reconnect_attempts++;
            std::cout << "[StreamManager] Reconnecting " << id 
                      << " (attempt " << info.reconnect_attempts << ")" << std::endl;
            
            doReconnect(id);
        }
    }
}

void StreamManager::stop()
{
    running_ = false;
    
    if (reconnect_thread_.joinable()) {
        reconnect_thread_.join();
    }
    
    std::lock_guard<std::mutex> lock(mutex_);
    
    for (auto &[id, info] : streams_)
    {
        if (info.source) {
            gst_element_set_state(info.source, GST_STATE_NULL);
        }
    }
    streams_.clear();
    std::cout << "[StreamManager] Stopped all streams" << std::endl;
}

void StreamManager::startReconnectThread()
{
    if (!reconnect_thread_.joinable()) {
        running_ = true;
        reconnect_thread_ = std::thread(&StreamManager::reconnectLoop, this);
    }
}
