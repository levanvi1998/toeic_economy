#include "ai_engine.h"
#include "gst_helper.h"
#include "metadata_writer.h"

#include <nvdsmeta.h>
#include <gstnvdsmeta.h>
#include <iostream>
#include <chrono>

AIEngine &AIEngine::instance()
{
    static AIEngine inst;
    return inst;
}

void AIEngine::init(GstElement *main_pipeline, uint32_t max_batch,
                    const std::string &infer_config_path,
                    const std::string &metadata_output_dir)
{

    // Create streammux
    streammux_ = GstHelper::createElement("nvstreammux", "global_mux");
    g_object_set(streammux_,
                 "batch-size", max_batch,
                 "width", 640,
                 "height", 640,
                 "batched-push-timeout", 40000,
                 "live-source", TRUE,
                 NULL);

    // Create nvinfer
    infer_ = GstHelper::createElement("nvinfer", "primary_infer");
    g_object_set(infer_,
                 "config-file-path", infer_config_path.c_str(),
                 NULL);

    // Create appsink
    sink_ = GstHelper::createElement("appsink", "ai_sink");
    g_object_set(sink_,
                 "emit-signals", TRUE,
                 "sync", FALSE,
                 "max-buffers", 1,
                 "drop", TRUE,
                 NULL);

    g_signal_connect(sink_, "new-sample", G_CALLBACK(onNewSample), this);

    // Add to pipeline
    gst_bin_add_many(GST_BIN(main_pipeline), streammux_, infer_, sink_, NULL);

    if (!gst_element_link_many(streammux_, infer_, sink_, NULL))
    {
        std::cerr << "[AIEngine] Failed to link AI pipeline" << std::endl;
    }

    // Start metadata writer
    MetadataWriter::instance().start(metadata_output_dir);

    std::cout << "[AIEngine] Initialized" << std::endl;
}

void AIEngine::shutdown()
{
    MetadataWriter::instance().stop();
}

GstFlowReturn AIEngine::onNewSample(GstAppSink *sink, gpointer user_data)
{
    AIEngine *self = static_cast<AIEngine *>(user_data);

    GstSample *sample = gst_app_sink_pull_sample(sink);
    if (!sample)
    {
        return GST_FLOW_ERROR;
    }

    GstBuffer *buffer = gst_sample_get_buffer(sample);
    self->processBuffer(buffer);

    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

void AIEngine::processBuffer(GstBuffer *buffer)
{
    NvDsBatchMeta *batch_meta = gst_buffer_get_nvds_batch_meta(buffer);
    if (!batch_meta)
        return;

    auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
                   std::chrono::system_clock::now().time_since_epoch())
                   .count();

    for (NvDsMetaList *l_frame = batch_meta->frame_meta_list;
         l_frame; l_frame = l_frame->next)
    {

        NvDsFrameMeta *frame = (NvDsFrameMeta *)l_frame->data;

        int pad_index = frame->pad_index;
        std::string stream_id = getStreamId(pad_index);
        uint64_t pts = frame->buf_pts;

        // Create metadata structure
        FrameMetadata meta;
        meta.stream_id = stream_id;
        meta.pts = pts;
        meta.timestamp = now;

        // Process objects
        for (NvDsMetaList *l_obj = frame->obj_meta_list;
             l_obj; l_obj = l_obj->next)
        {

            NvDsObjectMeta *obj = (NvDsObjectMeta *)l_obj->data;

            Detection det;
            det.class_id = obj->class_id;
            det.confidence = obj->confidence;
            det.x = obj->rect_params.left;
            det.y = obj->rect_params.top;
            det.w = obj->rect_params.width;
            det.h = obj->rect_params.height;

            meta.detections.push_back(det);

            // Console output
            printf("[%s] pts=%lu class=%d conf=%.2f bbox=(%.1f %.1f %.1f %.1f)\n",
                   stream_id.c_str(), pts, det.class_id, det.confidence,
                   det.x, det.y, det.w, det.h);
        }

        // Push to metadata writer
        MetadataWriter::instance().push(meta);
    }
}

GstPad *AIEngine::requestSinkPad(const std::string &stream_id)
{
    int index = pad_index_.fetch_add(1);
    std::string pad_name = "sink_" + std::to_string(index);

    std::cout << "[AIEngine] Requesting pad: " << pad_name << " for stream " << stream_id << std::endl;

    GstPad *pad = gst_element_request_pad_simple(streammux_, pad_name.c_str());
    if (!pad)
    {
        std::cerr << "[AIEngine] Failed to get streammux pad " << pad_name << std::endl;
        return nullptr;
    }

    registerStream(index, stream_id);
    return pad;
}

void AIEngine::releaseStream(const std::string &stream_id)
{
    int index = getPadIndex(stream_id);
    if (index < 0)
    {
        std::cerr << "[AIEngine] releaseStream: stream not found: " << stream_id << std::endl;
        return;
    }

    std::string pad_name = "sink_" + std::to_string(index);
    std::cout << "[AIEngine] Releasing pad " << pad_name << std::endl;

    GstPad *pad = gst_element_get_static_pad(streammux_, pad_name.c_str());
    if (pad)
    {
        gst_element_release_request_pad(streammux_, pad);
        gst_object_unref(pad);
    }

    unregisterStream(index);
}

void AIEngine::registerStream(int pad_index, const std::string &stream_id)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    pad_to_stream_[pad_index] = stream_id;
    stream_to_pad_[stream_id] = pad_index;
}

void AIEngine::unregisterStream(int pad_index)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = pad_to_stream_.find(pad_index);
    if (it != pad_to_stream_.end())
    {
        stream_to_pad_.erase(it->second);
        pad_to_stream_.erase(it);
    }
}

std::string AIEngine::getStreamId(int pad_index)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = pad_to_stream_.find(pad_index);
    return (it != pad_to_stream_.end()) ? it->second : "unknown";
}

int AIEngine::getPadIndex(const std::string &stream_id)
{
    std::lock_guard<std::mutex> lock(map_mutex_);
    auto it = stream_to_pad_.find(stream_id);
    return (it != stream_to_pad_.end()) ? it->second : -1;
}
