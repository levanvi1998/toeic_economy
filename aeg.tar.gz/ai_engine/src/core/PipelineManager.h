#pragma once
#include <unordered_map>
#include <memory>
#include <mutex>
#include "aws/S3Uploader.h"
#include "core/StreamSession.h"
#include <nlohmann/json.hpp>

class PipelineManager
{
public:
    PipelineManager(GstElement* main_pipeline,
                    std::shared_ptr<S3Uploader> s3,
                    const std::string &rtpHost,
                    const std::string &metadataWSUrl,
                    const std::string &mediasoupServerUrl,
                    const std::string &outputDir,
                    int reconnectIntervalMs = 5000,
                    int maxReconnectAttempts = 0);
    ~PipelineManager();

    GstElement* getMainPipeline() { return main_pipeline_; }

    // Stream lifecycle
    bool createStream(const std::string &id, const std::string &uri);
    bool deleteStream(const std::string &id);
    bool startStream(const std::string &id);
    bool stopStream(const std::string &id);

    // Recording control
    bool startRecording(const std::string &id);
    bool stopRecording(const std::string &id);

    // Stream info
    std::vector<std::string> listStreams();
    nlohmann::json getStreamInfo(const std::string &id);

    // Cleanup all streams (notify nodejs)
    void cleanupAllStreams();

private:
    std::unordered_map<std::string, std::shared_ptr<StreamSession>> sessions_;
    std::mutex mux_;
    GstElement* main_pipeline_;
    std::shared_ptr<S3Uploader> s3_;
    std::string rtpHost_;
    std::string metadataWSUrl_;
    std::string mediasoupServerUrl_;
    std::string outputDir_;
    int reconnect_interval_ms_;
    int max_reconnect_attempts_;
};
