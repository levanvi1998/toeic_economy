#include "StreamSession.h"
#include "pipeline/DeepStreamPipelineBuilder.h"
#include "pipeline/VideoRecorder.h"
#include "ai/AIEngine.h"
#include "util/Logger.h"
#include <nlohmann/json.hpp>
#include <iostream>
#include <cstring>
#include <chrono>
#include "httplib.h"

using json = nlohmann::json;

StreamSession::StreamSession(GstElement* main_pipeline,
                             const std::string &id,
                             const std::string &uri,
                             const std::string &rtpHost,
                             const std::string &metadataWSUrl,
                             const std::string &mediasoupServerUrl,
                             const std::string &outputDir,
                             std::shared_ptr<S3Uploader> s3,
                             int reconnectIntervalMs,
                             int maxReconnectAttempts)
    : main_pipeline_(main_pipeline), id_(id), uri_(uri), rtpHost_(rtpHost), rtpPort_(0), rtcpPort_(0), ssrc_(0),
      metadataWSUrl_(metadataWSUrl), mediasoupServerUrl_(mediasoupServerUrl), outputDir_(outputDir), s3_(s3),
      reconnect_interval_ms_(reconnectIntervalMs), max_reconnect_attempts_(maxReconnectAttempts)
{
    // Create VideoRecorder for this stream
    recorder_ = std::make_unique<VideoRecorder>(id_, outputDir_, s3_);
    recorder_->setRemoveAfterUpload(true);
    metadataWS_ = std::make_unique<MetadataWSClient>(metadataWSUrl_);
}

StreamSession::~StreamSession()
{
    stop();
}

bool StreamSession::registerWithMediasoup()
{
    if (mediasoupServerUrl_.empty())
    {
        rtpPort_ = 5004;  // Use default if no mediasoup
        rtcpPort_ = 5005; // RTCP is typically RTP + 1
        ssrc_ = 0x12345678; // Default SSRC
        return true;
    }

    try
    {
        // Parse URL to extract host and port
        std::string url = mediasoupServerUrl_ + "/streams/" + id_ + "/start";
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000; // default
        std::string path = "/streams/" + id_ + "/start";

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(5, 0);
        cli.set_read_timeout(5, 0);
        cli.set_write_timeout(5, 0);

        LOG_INFO("StreamSession", "[%s] Registering with mediasoup at %s:%d%s", id_.c_str(), host.c_str(), port, path.c_str());
        auto res = cli.Post(path.c_str());

        if (res && res->status == 200)
        {
            try
            {
                auto response = json::parse(res->body);
                if (response.contains("rtpPort"))
                {
                    rtpPort_ = response["rtpPort"];
                    rtcpPort_ = response.value("rtcpPort", rtpPort_ + 1);
                    ssrc_ = response.value("ssrc", 0x12345678);
                    
                    LOG_INFO("StreamSession", "[%s] Mediasoup ready - RTP:%d RTCP:%d SSRC:0x%08X",
                             id_.c_str(), rtpPort_, rtcpPort_, ssrc_);
                    return true;
                }
            }
            catch (std::exception &e)
            {
                LOG_ERROR("StreamSession", "[%s] Failed to parse mediasoup response: %s", id_.c_str(), e.what());
            }
        }
    }
    catch (std::exception &e)
    {
        LOG_ERROR("StreamSession", "[%s] Error contacting mediasoup: %s", id_.c_str(), e.what());
    }

    // Fallback if registration failed
    if (rtpPort_ == 0)
    {
        rtpPort_ = 5004;
        rtcpPort_ = 5005;
        ssrc_ = 0x12345678;
        LOG_WARN("StreamSession", "[%s] Mediasoup registration failed, using fallback ports", id_.c_str());
    }
    return false;
}

bool StreamSession::checkNodejsServerHealth()
{
    if (mediasoupServerUrl_.empty())
        return true;

    try
    {
        // Parse URL
        std::string url = mediasoupServerUrl_ + "/streams";
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000;

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(5, 0);
        auto res = cli.Get("/streams");

        return (res && (res->status == 200 || res->status == 404));
    }
    catch (...)
    {
        return false;
    }
}

void StreamSession::notifyMediasoupStreamDeleted()
{
    if (mediasoupServerUrl_.empty())
        return;

    try
    {
        std::string url = mediasoupServerUrl_ + "/streams/" + id_;
        size_t protocolEnd = url.find("://");
        size_t hostStart = protocolEnd != std::string::npos ? protocolEnd + 3 : 0;
        size_t portStart = url.find(":", hostStart);
        size_t pathStart = url.find("/", hostStart);

        std::string host;
        int port = 3000;
        std::string path = "/streams/" + id_;

        if (portStart != std::string::npos && portStart < pathStart)
        {
            host = url.substr(hostStart, portStart - hostStart);
            port = std::stoi(url.substr(portStart + 1, pathStart - portStart - 1));
        }
        else
        {
            host = url.substr(hostStart, pathStart - hostStart);
        }

        httplib::Client cli(host, port);
        cli.set_connection_timeout(2, 0);
        
        LOG_INFO("StreamSession", "[%s] Notifying mediasoup to delete stream", id_.c_str());
        auto res = cli.Delete(path.c_str());
        
        if (res && res->status == 200)
        {
            LOG_INFO("StreamSession", "[%s] Mediasoup stream deleted", id_.c_str());
        }
        else if (res)
        {
            LOG_WARN("StreamSession", "[%s] Mediasoup delete returned status %d", id_.c_str(), res->status);
        }
    }
    catch (std::exception &e)
    {
        LOG_WARN("StreamSession", "[%s] Failed to notify mediasoup: %s", id_.c_str(), e.what());
    }
}

void StreamSession::start()
{
    if (running_)
    {
        LOG_WARN("StreamSession", "[%s] Already running", id_.c_str());
        return;
    }

    LOG_INFO("StreamSession", "[%s] Starting stream: %s", id_.c_str(), uri_.c_str());
    stopping_ = false;
    reconnect_attempts_ = 0;
    last_pipeline_build_time_ = std::chrono::steady_clock::now();

    // Register with mediasoup to get RTP ports
    registerWithMediasoup();

    // Connect metadata websocket
    metadataWS_->connect();

    // Build pipeline
    if (!buildPipeline()) {
        LOG_ERROR("StreamSession", "[%s] Failed to build pipeline, scheduling reconnect", id_.c_str());
        scheduleReconnect();
        return;
    }
    
    running_ = true;
    last_pipeline_build_time_ = std::chrono::steady_clock::now();
    LOG_INFO("StreamSession", "[%s] Stream started successfully", id_.c_str());
}

bool StreamSession::buildPipeline()
{
    LOG_INFO("StreamSession", "[%s] Building pipeline...", id_.c_str());
    
    pipeline_bin_ = DeepStreamPipelineBuilder::build(
        main_pipeline_,
        id_,
        uri_,
        rtpHost_,
        rtpPort_,
        rtcpPort_,
        ssrc_,
        outputDir_,
        recorder_.get()
    );

    if (!pipeline_bin_)
    {
        LOG_ERROR("StreamSession", "[%s] Failed to build pipeline", id_.c_str());
        return false;
    }

    LOG_INFO("StreamSession", "[%s] Pipeline built, setting up bus watch...", id_.c_str());
    
    // Setup bus watch for error handling
    GstBus* bus = gst_pipeline_get_bus(GST_PIPELINE(main_pipeline_));
    if (bus) {
        bus_watch_id_ = gst_bus_add_watch(bus, onBusMessage, this);
        gst_object_unref(bus);
    }
    
    // Sync source element state with main pipeline
    gst_element_sync_state_with_parent(pipeline_bin_);
    
    // Wire AI metadata callback to WebSocket and buffer
    AIEngine::instance().setMetadataCallback(id_, [this](const FrameMetadata& meta) {
        // Skip empty frames
        if (meta.detections.empty()) {
            return;
        }
        
        // Format: {"stream": "video1", "ts_ms": 1234, "pts": 5678, "frame_width": 640, "frame_height": 640, "count": 2, "detections": [...]}
        nlohmann::json j;
        j["stream"] = meta.stream_id;
        j["ts_ms"] = meta.timestamp;
        j["pts"] = meta.pts;
        j["frame_width"] = meta.frame_width;
        j["frame_height"] = meta.frame_height;
        j["count"] = meta.detections.size();
        j["detections"] = nlohmann::json::array();
        
        for (const auto& det : meta.detections) {
            nlohmann::json detection;
            detection["class"] = det.class_name;
            detection["class_id"] = det.class_id;
            detection["confidence"] = det.confidence;
            detection["bbox"] = {
                {"x", static_cast<int>(det.x)},
                {"y", static_cast<int>(det.y)},
                {"width", static_cast<int>(det.w)},
                {"height", static_cast<int>(det.h)}
            };
            j["detections"].push_back(detection);
        }
        
        std::string json_str = j.dump();
        
        // Send to WebSocket (real-time)
        if (metadataWS_ && metadataWS_->isConnected()) {
            metadataWS_->send(json_str);
        }
        
        // Buffer metadata for segment file (will be flushed when video segment is ready)
        if (recorder_) {
            recorder_->appendMetadata(json_str);
        }
    });
    
    return true;
}

void StreamSession::stop()
{
    if (stopping_)
        return;
    
    stopping_ = true;

    LOG_INFO("StreamSession", "[%s] Stopping stream", id_.c_str());

    // Cancel any pending reconnect timer
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        if (reconnect_timer_id_ > 0) {
            g_source_remove(reconnect_timer_id_);
            reconnect_timer_id_ = 0;
        }
    }
    
    // Wait for reconnect thread to finish
    if (reconnect_thread_ && reconnect_thread_->joinable()) {
        reconnect_thread_->join();
        reconnect_thread_.reset();
    }

    // Stop recording if active
    if (recording_)
    {
        stopRecording();
    }

    // Clear metadata callback to avoid dangling references
    AIEngine::instance().removeMetadataCallback(id_);
    
    // Disconnect metadata websocket
    if (metadataWS_)
    {
        metadataWS_->disconnect();
    }

    // Remove bus watch
    if (bus_watch_id_ > 0) {
        g_source_remove(bus_watch_id_);
        bus_watch_id_ = 0;
    }

    // Destroy pipeline
    destroyPipeline();

    running_ = false;

    // Notify mediasoup
    notifyMediasoupStreamDeleted();

    LOG_INFO("StreamSession", "[%s] Stream stopped", id_.c_str());
}

void StreamSession::destroyPipeline()
{
    if (!pipeline_bin_)
        return;

    if (!GST_IS_ELEMENT(pipeline_bin_)) {
        LOG_WARN("StreamSession", "[%s] pipeline_bin_ is not a valid GstElement", id_.c_str());
        pipeline_bin_ = nullptr;
        return;
    }

    LOG_INFO("StreamSession", "[%s] Removing pipeline elements", id_.c_str());

    // Set state to NULL
    gst_element_set_state(pipeline_bin_, GST_STATE_NULL);

    // Wait until the per-stream bin really reaches NULL
    GstState current = GST_STATE_VOID_PENDING;
    GstState pending = GST_STATE_VOID_PENDING;
    GstStateChangeReturn scr = gst_element_get_state(pipeline_bin_, &current, &pending, 2 * GST_SECOND);
    if (scr == GST_STATE_CHANGE_ASYNC) {
        scr = gst_element_get_state(pipeline_bin_, &current, &pending, 2 * GST_SECOND);
    }
    if (current != GST_STATE_NULL) {
        LOG_WARN("StreamSession", "[%s] Stream bin state not NULL before remove (cur=%s pending=%s)",
                 id_.c_str(), gst_element_state_get_name(current), gst_element_state_get_name(pending));
    }
    
    // Remove from main pipeline
    if (main_pipeline_ && GST_IS_BIN(main_pipeline_)) {
        gst_bin_remove(GST_BIN(main_pipeline_), pipeline_bin_);
    }
    pipeline_bin_ = nullptr;

    // Release AI engine resources
    AIEngine::instance().releaseStream(id_);
}

void StreamSession::startRecording()
{
    if (recording_)
    {
        LOG_WARN("StreamSession", "[%s] Already recording", id_.c_str());
        return;
    }

    LOG_INFO("StreamSession", "[%s] Starting recording", id_.c_str());
    
    if (recorder_)
    {
        // TODO: Integrate recorder with pipeline
        recording_ = true;
        LOG_INFO("StreamSession", "[%s] Recording started", id_.c_str());
    }
}

void StreamSession::stopRecording()
{
    if (!recording_)
        return;

    LOG_INFO("StreamSession", "[%s] Stopping recording", id_.c_str());
    
    if (recorder_)
    {
        // TODO: Stop recorder
        recording_ = false;
        LOG_INFO("StreamSession", "[%s] Recording stopped", id_.c_str());
    }
}

// ============================================================================
// Bus message handler - catches errors from pipeline
// ============================================================================

gboolean StreamSession::onBusMessage(GstBus* bus, GstMessage* msg, gpointer user_data)
{
    StreamSession* self = static_cast<StreamSession*>(user_data);
    if (!self || self->stopping_ || self->reconnecting_) return TRUE;

    // Helper to check if message source belongs to our stream
    auto isOurElement = [self](GstMessage* msg) -> bool {
        if (!self->pipeline_bin_) return false;
        
        GstObject* src = GST_MESSAGE_SRC(msg);
        if (!src) return false;
        
        // Check element name contains our stream ID
        const gchar* name = GST_OBJECT_NAME(src);
        if (name && strstr(name, self->id_.c_str())) {
            return true;
        }
        
        // Check hierarchy
        if (GST_IS_ELEMENT(src)) {
            GstElement* parent = GST_ELEMENT(src);
            while (parent) {
                if (parent == self->pipeline_bin_) {
                    return true;
                }
                parent = GST_ELEMENT_PARENT(parent);
            }
        }
        
        return false;
    };

    switch (GST_MESSAGE_TYPE(msg)) {
        case GST_MESSAGE_ERROR: {
            if (!isOurElement(msg)) break;
            
            GError* err = nullptr;
            gchar* debug = nullptr;
            gst_message_parse_error(msg, &err, &debug);
            
            const gchar* src_name = GST_MESSAGE_SRC(msg) ? GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)) : "unknown";
            LOG_ERROR("StreamSession", "[%s] Pipeline error from %s: %s", 
                      self->id_.c_str(), src_name, err->message);
            
            // Only reconnect for source-related errors (rtspsrc, urisourcebin, decodebin)
            // Don't reconnect for muxer/encoder/output errors (qtmux, nvv4l2h264enc, udpsink)
            bool is_source_error = false;
            if (src_name) {
                if (strstr(src_name, "rtspsrc") ||
                    strstr(src_name, "urisourcebin") ||
                    strstr(src_name, "decodebin") ||
                    strstr(src_name, "rtsp") ||
                    strstr(src_name, "source")) {
                    is_source_error = true;
                }
            }
            
            // Also check error message for connection issues
            if (err->message) {
                if (strstr(err->message, "Could not open resource") ||
                    strstr(err->message, "Not found") ||
                    strstr(err->message, "connection") ||
                    strstr(err->message, "Connection") ||
                    strstr(err->message, "timed out") ||
                    strstr(err->message, "Could not read")) {
                    is_source_error = true;
                }
            }
            
            g_error_free(err);
            g_free(debug);
            
            if (is_source_error) {
                self->scheduleReconnect();
            } else {
                LOG_WARN("StreamSession", "[%s] Non-source error, not reconnecting", self->id_.c_str());
            }
            break;
        }
        
        case GST_MESSAGE_WARNING: {
            if (!isOurElement(msg)) break;
            
            GError* err = nullptr;
            gchar* debug = nullptr;
            gst_message_parse_warning(msg, &err, &debug);
            
            const gchar* src_name = GST_MESSAGE_SRC(msg) ? GST_OBJECT_NAME(GST_MESSAGE_SRC(msg)) : "unknown";
            LOG_WARN("StreamSession", "[%s] Warning from %s: %s", 
                     self->id_.c_str(), src_name, err->message);
            
            // Check for connection-related warnings that indicate stream loss
            bool connection_lost = false;
            if (err->message) {
                if (strstr(err->message, "closed") ||
                    strstr(err->message, "timed out") ||
                    strstr(err->message, "timeout") ||
                    strstr(err->message, "connection") ||
                    strstr(err->message, "Could not read")) {
                    connection_lost = true;
                }
            }
            
            g_error_free(err);
            g_free(debug);
            
            if (connection_lost) {
                LOG_WARN("StreamSession", "[%s] Connection lost, scheduling reconnect", self->id_.c_str());
                self->scheduleReconnect();
            }
            break;
        }
        
        case GST_MESSAGE_EOS: {
            // EOS can come from main pipeline when source ends
            // Check if it's related to our stream
            GstObject* src = GST_MESSAGE_SRC(msg);
            const gchar* src_name = src ? GST_OBJECT_NAME(src) : "unknown";
            
            bool is_our_eos = isOurElement(msg);
            
            // Also check if EOS is from main pipeline (nvstreammux sent EOS for our source)
            if (!is_our_eos && src == GST_OBJECT(self->main_pipeline_)) {
                // Main pipeline EOS - could be for our stream
                // Check if our pipeline_bin is still there
                if (self->pipeline_bin_ && self->running_) {
                    is_our_eos = true;
                }
            }
            
            if (is_our_eos) {
                LOG_WARN("StreamSession", "[%s] EOS from %s, scheduling reconnect", 
                         self->id_.c_str(), src_name);
                self->scheduleReconnect();
            }
            break;
        }
        
        case GST_MESSAGE_ELEMENT: {
            // Handle custom messages from urisourcebin/rtspsrc
            if (!isOurElement(msg)) break;
            
            const GstStructure* s = gst_message_get_structure(msg);
            if (s) {
                const gchar* name = gst_structure_get_name(s);
                if (name) {
                    // rtspsrc sends "GstRTSPSrcTimeout" when connection times out
                    if (strstr(name, "Timeout") || strstr(name, "timeout") ||
                        strstr(name, "error") || strstr(name, "Error")) {
                        LOG_WARN("StreamSession", "[%s] Element message: %s, scheduling reconnect", 
                                 self->id_.c_str(), name);
                        self->scheduleReconnect();
                    }
                }
            }
            break;
        }
        
        case GST_MESSAGE_APPLICATION: {
            // Handle custom application messages (e.g., stream-eos from EOS probe)
            const GstStructure* s = gst_message_get_structure(msg);
            if (s) {
                const gchar* name = gst_structure_get_name(s);
                if (name && strcmp(name, "stream-eos") == 0) {
                    const gchar* sid = gst_structure_get_string(s, "stream-id");
                    if (sid && strcmp(sid, self->id_.c_str()) == 0) {
                        LOG_WARN("StreamSession", "[%s] Stream EOS detected, scheduling reconnect", self->id_.c_str());
                        self->scheduleReconnect();
                    }
                }
            }
            break;
        }
        
        case GST_MESSAGE_STATE_CHANGED: {
            // Only log for our pipeline bin
            if (GST_MESSAGE_SRC(msg) == GST_OBJECT(self->pipeline_bin_)) {
                GstState old_state, new_state, pending_state;
                gst_message_parse_state_changed(msg, &old_state, &new_state, &pending_state);
                LOG_DEBUG("StreamSession", "[%s] State: %s -> %s", 
                          self->id_.c_str(),
                          gst_element_state_get_name(old_state),
                          gst_element_state_get_name(new_state));
            }
            break;
        }
        
        default:
            break;
    }
    
    return TRUE;
}

// ============================================================================
// Reconnection logic
// ============================================================================

void StreamSession::scheduleReconnect()
{
    std::lock_guard<std::mutex> lock(reconnect_mutex_);
    
    if (stopping_) {
        LOG_DEBUG("StreamSession", "[%s] Not scheduling reconnect - stopping", id_.c_str());
        return;
    }
    
    if (reconnecting_) {
        LOG_DEBUG("StreamSession", "[%s] Already reconnecting, skipping", id_.c_str());
        return;
    }
    
    if (reconnect_timer_id_ > 0) {
        LOG_DEBUG("StreamSession", "[%s] Reconnect already scheduled", id_.c_str());
        return;
    }
    
    // Check if stream was stable before this error
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_pipeline_build_time_).count();
    
    if (elapsed > STABILITY_THRESHOLD_MS && reconnect_attempts_ > 0) {
        // Stream was running for more than threshold - it was stable, reset attempts
        LOG_INFO("StreamSession", "[%s] Stream was stable for %ldms, resetting attempt counter", id_.c_str(), elapsed);
        reconnect_attempts_ = 0;
    }
    
    // Check max attempts (0 = unlimited)
    if (max_reconnect_attempts_ > 0 && reconnect_attempts_ >= max_reconnect_attempts_) {
        LOG_ERROR("StreamSession", "[%s] Max reconnect attempts (%d) reached, giving up", 
                  id_.c_str(), max_reconnect_attempts_);
        running_ = false;
        return;
    }
    
    reconnecting_ = true;
    // Note: reconnect_attempts_ is incremented in attemptReconnect(), not here
    
    int next_attempt = reconnect_attempts_ + 1;
    LOG_INFO("StreamSession", "[%s] Scheduling reconnect in %dms (will be attempt %d%s)", 
             id_.c_str(), reconnect_interval_ms_, next_attempt,
             max_reconnect_attempts_ > 0 ? ("/" + std::to_string(max_reconnect_attempts_)).c_str() : "");
    
    // Cancel any existing timer
    if (reconnect_timer_id_ > 0) {
        g_source_remove(reconnect_timer_id_);
    }
    
    // Schedule reconnect using GLib timeout (runs in main loop context)
    reconnect_timer_id_ = g_timeout_add(reconnect_interval_ms_, 
        [](gpointer user_data) -> gboolean {
            StreamSession* self = static_cast<StreamSession*>(user_data);
            self->attemptReconnect();
            return G_SOURCE_REMOVE;
        }, this);
}

void StreamSession::attemptReconnect()
{
    {
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        reconnect_timer_id_ = 0;
    }
    
    if (stopping_) {
        reconnecting_ = false;
        return;
    }
    
    // Wait for previous reconnect thread to finish
    if (reconnect_thread_ && reconnect_thread_->joinable()) {
        reconnect_thread_->join();
    }
    
    // Spawn reconnect in separate thread to avoid blocking GLib main loop
    reconnect_thread_ = std::make_unique<std::thread>(&StreamSession::reconnectThreadFunc, this);
}

void StreamSession::reconnectThreadFunc()
{
    reconnect_attempts_++;
    LOG_INFO("StreamSession", "[%s] Attempting reconnect (attempt %d%s)...", 
             id_.c_str(), reconnect_attempts_.load(),
             max_reconnect_attempts_ > 0 ? ("/" + std::to_string(max_reconnect_attempts_)).c_str() : "");
    
    // Clean up old pipeline - GStreamer is thread-safe for these operations
    if (bus_watch_id_ > 0) {
        g_source_remove(bus_watch_id_);
        bus_watch_id_ = 0;
    }
    
    AIEngine::instance().removeMetadataCallback(id_);
    destroyPipeline();
    
    if (stopping_) {
        reconnecting_ = false;
        return;
    }
    
    // Check if mediasoup server is healthy before trying to register
    bool mediasoup_ok = true;
    if (!mediasoupServerUrl_.empty()) {
        mediasoup_ok = checkNodejsServerHealth();
        if (!mediasoup_ok) {
            LOG_WARN("StreamSession", "[%s] Mediasoup server not available, will retry...", id_.c_str());
        }
    }
    
    // Re-register with mediasoup (get new ports if needed)
    bool registered = false;
    if (mediasoup_ok) {
        registered = registerWithMediasoup();
        if (!registered && !mediasoupServerUrl_.empty()) {
            LOG_WARN("StreamSession", "[%s] Failed to register with mediasoup", id_.c_str());
        }
    }
    
    // Build pipeline
    bool pipeline_ok = false;
    if (mediasoup_ok || mediasoupServerUrl_.empty()) {
        pipeline_ok = buildPipeline();
    }
    
    if (pipeline_ok) {
        LOG_INFO("StreamSession", "[%s] Reconnected - pipeline built, waiting for stream...", id_.c_str());
        reconnecting_ = false;
        running_ = true;
        last_pipeline_build_time_ = std::chrono::steady_clock::now();
        // Note: Don't reset reconnect_attempts_ here - will reset when we confirm stream is stable
        // (i.e., no error within a few seconds)
        return;  // Success - exit early
    }
    
    // Failed - check max attempts before retry
    if (max_reconnect_attempts_ > 0 && reconnect_attempts_ >= max_reconnect_attempts_) {
        LOG_ERROR("StreamSession", "[%s] Max reconnect attempts (%d) reached, giving up", 
                  id_.c_str(), max_reconnect_attempts_);
        reconnecting_ = false;
        running_ = false;
        return;
    }
    
    LOG_WARN("StreamSession", "[%s] Reconnect failed, retry in %dms", 
             id_.c_str(), reconnect_interval_ms_);
    
    // Sleep then schedule next attempt via g_timeout_add (thread-safe)
    std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_interval_ms_));
    
    if (!stopping_) {
        // Note: g_timeout_add is thread-safe
        std::lock_guard<std::mutex> lock(reconnect_mutex_);
        reconnect_timer_id_ = g_timeout_add(0,  // Run immediately in main loop
            [](gpointer user_data) -> gboolean {
                StreamSession* self = static_cast<StreamSession*>(user_data);
                if (!self->stopping_) {
                    self->attemptReconnect();
                }
                return G_SOURCE_REMOVE;
            }, this);
    }
}
