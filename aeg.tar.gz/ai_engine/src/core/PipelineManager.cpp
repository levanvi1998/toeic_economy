#include "PipelineManager.h"
#include "util/Logger.h"
#include <iostream>

PipelineManager::PipelineManager(GstElement* main_pipeline,
                                 std::shared_ptr<S3Uploader> s3,
                                 const std::string &rtpHost,
                                 const std::string &metadataWSUrl,
                                 const std::string &mediasoupServerUrl,
                                 const std::string &outputDir,
                                 int reconnectIntervalMs,
                                 int maxReconnectAttempts)
    : main_pipeline_(main_pipeline), s3_(s3), rtpHost_(rtpHost),
      metadataWSUrl_(metadataWSUrl), mediasoupServerUrl_(mediasoupServerUrl), outputDir_(outputDir),
      reconnect_interval_ms_(reconnectIntervalMs), max_reconnect_attempts_(maxReconnectAttempts) {}

PipelineManager::~PipelineManager()
{
    // First notify nodejs to delete all streams
    cleanupAllStreams();

    // Then stop all sessions
    std::lock_guard<std::mutex> lk(mux_);
    for (auto &p : sessions_)
    {
        p.second->stop();
    }
    sessions_.clear();
}

void PipelineManager::cleanupAllStreams()
{
    std::lock_guard<std::mutex> lk(mux_);
    LOG_INFO("PipelineManager", "Cleaning up %zu streams", sessions_.size());
    // Note: We don't call stop() here because the destructor will do it
    // We just want to notify nodejs about all streams before they're stopped
    // The stop() method will call notifyMediasoupStreamDeleted() for each stream
}

bool PipelineManager::createStream(const std::string &id, const std::string &uri)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        if (sessions_.count(id))
        {
            LOG_WARN("PipelineManager", "Stream %s already exists", id.c_str());
            return false;
        }

        session = std::make_shared<StreamSession>(main_pipeline_, id, uri, rtpHost_, metadataWSUrl_, 
                                                   mediasoupServerUrl_, outputDir_, s3_,
                                                   reconnect_interval_ms_, max_reconnect_attempts_);
        sessions_.emplace(id, session);
        LOG_INFO("PipelineManager", "Stream %s created, starting...", id.c_str());
    }

    // Start OUTSIDE of lock to avoid blocking other operations
    try
    {
        session->start();
        LOG_INFO("PipelineManager", "Stream %s started successfully", id.c_str());
    }
    catch (std::exception &e)
    {
        LOG_ERROR("PipelineManager", "Failed to start stream %s: %s", id.c_str(), e.what());
        // Remove from map if start failed
        std::lock_guard<std::mutex> lk(mux_);
        sessions_.erase(id);
        throw;
    }

    return true;
}

bool PipelineManager::deleteStream(const std::string &id)
{
    LOG_INFO("PipelineManager", "deleteStream() called for stream: %s", id.c_str());
    std::shared_ptr<StreamSession> session;

    {
        LOG_INFO("PipelineManager", "Acquiring lock for delete stream: %s", id.c_str());
        std::lock_guard<std::mutex> lk(mux_);
        LOG_INFO("PipelineManager", "Lock acquired, finding stream: %s", id.c_str());
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            LOG_WARN("PipelineManager", "Stream %s not found", id.c_str());
            return false;
        }

        // Move session out and remove from map immediately
        session = std::move(it->second);
        sessions_.erase(it);
        LOG_INFO("PipelineManager", "Stream %s removed from map, stopping asynchronously...", id.c_str());
    }

    // Stop in detached thread to avoid blocking HTTP response
    // The session will be destroyed when the thread completes
    std::thread([session, id]()
                {
        session->stop();
        LOG_INFO("PipelineManager", "Stream %s fully stopped and cleaned up", id.c_str()); })
        .detach();

    return true;
}

bool PipelineManager::startStream(const std::string &id)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }

        if (it->second->isRunning())
        {
            return true;
        }

        session = it->second;
    }

    // Start in detached thread to avoid blocking HTTP response
    // (may need to check health, connect websocket, register with mediasoup)
    std::thread([session, id]()
                {
        try {
            session->start();
            LOG_INFO("PipelineManager", "Stream %s started", id.c_str());
        } catch (std::exception& e) {
            LOG_ERROR("PipelineManager", "Failed to start stream %s: %s", id.c_str(), e.what());
        } })
        .detach();

    return true;
}

bool PipelineManager::stopStream(const std::string &id)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }

        if (!it->second->isRunning())
        {
            return true;
        }

        session = it->second;
    }

    // Stop in detached thread to avoid blocking HTTP response
    std::thread([session, id]()
                {
        session->stop();
        LOG_INFO("PipelineManager", "Stream %s stopped", id.c_str()); })
        .detach();

    return true;
}

bool PipelineManager::startRecording(const std::string &id)
{
    std::lock_guard<std::mutex> lk(mux_);
    auto it = sessions_.find(id);
    if (it == sessions_.end())
    {
        return false;
    }

    it->second->startRecording();
    return true;
}

bool PipelineManager::stopRecording(const std::string &id)
{
    std::shared_ptr<StreamSession> session;

    {
        std::lock_guard<std::mutex> lk(mux_);
        auto it = sessions_.find(id);
        if (it == sessions_.end())
        {
            return false;
        }
        session = it->second;
    }

    // Stop recording in detached thread to avoid blocking HTTP response
    // (flushMetadata may upload to S3 which can be slow)
    std::thread([session, id]()
                {
        session->stopRecording();
        LOG_INFO("PipelineManager", "Recording stopped for stream %s", id.c_str()); })
        .detach();

    return true;
}

nlohmann::json PipelineManager::getStreamInfo(const std::string &id)
{
    std::lock_guard<std::mutex> lk(mux_);
    auto it = sessions_.find(id);
    nlohmann::json info;
    if (it == sessions_.end())
    {
        info["error"] = "stream not found";
        return info;
    }
    info["stream_id"] = id;
    info["running"] = it->second->isRunning();
    info["recording"] = it->second->isRecording();
    return info;
}

std::vector<std::string> PipelineManager::listStreams()
{
    std::lock_guard<std::mutex> lk(mux_);
    std::vector<std::string> out;
    for (auto &p : sessions_)
    {
        out.push_back(p.first);
    }
    return out;
}
