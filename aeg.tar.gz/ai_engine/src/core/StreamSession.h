#pragma once
#include <string>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include "aws/S3Uploader.h"
#include "pipeline/VideoRecorder.h"
#include "ws/MetadataWSClient.h"
#include <gst/gst.h>

class StreamSession
{
public:
    StreamSession(GstElement* main_pipeline,
                  const std::string &id,
                  const std::string &uri,
                  const std::string &rtpHost,
                  const std::string &metadataWSUrl,
                  const std::string &mediasoupServerUrl,
                  const std::string &outputDir,
                  std::shared_ptr<S3Uploader> s3,
                  int reconnectIntervalMs = 5000,
                  int maxReconnectAttempts = 0);
    ~StreamSession();

    void start();
    void stop();
    bool isRunning() const { return running_; }

    // Recording control
    void startRecording();
    void stopRecording();
    bool isRecording() const { return recording_; }

    std::string getStreamId() const { return id_; }

private:
    bool registerWithMediasoup();
    void notifyMediasoupStreamDeleted();
    bool checkNodejsServerHealth();
    
    // Pipeline management
    bool buildPipeline();
    void destroyPipeline();
    
    // Reconnection
    void scheduleReconnect();
    void attemptReconnect();
    void reconnectThreadFunc();  // Runs in separate thread
    static gboolean onBusMessage(GstBus* bus, GstMessage* msg, gpointer user_data);

    std::string id_;
    std::string uri_;
    std::string rtpHost_;
    int rtpPort_;
    int rtcpPort_;
    unsigned int ssrc_;
    std::string metadataWSUrl_;
    std::string mediasoupServerUrl_;
    std::string outputDir_;
    std::shared_ptr<S3Uploader> s3_;
    std::unique_ptr<VideoRecorder> recorder_;
    std::unique_ptr<MetadataWSClient> metadataWS_;

    GstElement* main_pipeline_ = nullptr;
    GstElement* pipeline_bin_ = nullptr;
    guint bus_watch_id_ = 0;
    
    std::atomic<bool> running_{false};
    std::atomic<bool> recording_{false};
    std::atomic<bool> stopping_{false};
    std::atomic<bool> reconnecting_{false};
    
    // Reconnection config
    int reconnect_interval_ms_;
    int max_reconnect_attempts_;
    std::atomic<int> reconnect_attempts_{0};
    guint reconnect_timer_id_ = 0;
    std::mutex reconnect_mutex_;
    std::unique_ptr<std::thread> reconnect_thread_;
    
    // Track when pipeline was last built (for stability check)
    std::chrono::steady_clock::time_point last_pipeline_build_time_;
    static constexpr int STABILITY_THRESHOLD_MS = 3000; // Wait 3s before considering stream stable
};
