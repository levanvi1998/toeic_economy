#include "app/AppConfig.h"
#include "ai/AIEngine.h"
#include "aws/S3Uploader.h"
#include "core/PipelineManager.h"
#include "http/HTTPServer.h"
#include "util/Logger.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <memory>
#include <cctype>
#include <signal.h>
#include <gst/gst.h>

std::atomic<bool> running{true};
GMainLoop* g_main_loop = nullptr;

void signal_handler(int signal)
{
    LOG_WARN("Main", "Received signal %d, shutting down...", signal);
    running = false;
    if (g_main_loop)
    {
        g_main_loop_quit(g_main_loop);
    }
}

GstDebugLevel gstLogLevelFromString(const std::string& level) {
    if (level == "none" || level == "0") return GST_LEVEL_NONE;
    if (level == "error" || level == "1") return GST_LEVEL_ERROR;
    if (level == "warning" || level == "2") return GST_LEVEL_WARNING;
    if (level == "fixme" || level == "3") return GST_LEVEL_FIXME;
    if (level == "info" || level == "4") return GST_LEVEL_INFO;
    if (level == "debug" || level == "5") return GST_LEVEL_DEBUG;
    if (level == "log" || level == "6") return GST_LEVEL_LOG;
    if (level == "trace" || level == "7") return GST_LEVEL_TRACE;
    if (level == "memdump" || level == "8") return GST_LEVEL_MEMDUMP;
    if (level == "9") return GST_LEVEL_MEMDUMP;
    return GST_LEVEL_WARNING;
}

int main(int argc, char **argv)
{
    // Initialize GStreamer
    gst_init(&argc, &argv);

    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // Load config
    AppConfig cfg = AppConfig::load("config.json");

    // Initialize Logger
    Logger::getInstance().setLogLevel(logLevelFromString(cfg.logLevel));
    LOG_INFO("Main", "Application log level set to: %s", cfg.logLevel.c_str());

    // Set GStreamer log level
    gst_debug_set_default_threshold(gstLogLevelFromString(cfg.gstLogLevel));
    LOG_INFO("Main", "GStreamer log level set to: %s", cfg.gstLogLevel.c_str());

    // Create main pipeline (required as container for DeepStream elements)
    GstElement *main_pipeline = gst_pipeline_new("main");
    if (!main_pipeline) {
        LOG_ERROR("Main", "Failed to create main pipeline");
        return -1;
    }

    // Initialize AIEngine with DeepStream
    AIEngine::instance().init(main_pipeline, cfg.maxStreams, cfg.inferConfigPath);

    auto s3 = std::make_shared<S3Uploader>(
        cfg.s3Bucket,
        cfg.s3Region,
        cfg.s3Endpoint,
        cfg.s3AccessKey,
        cfg.s3SecretKey,
        cfg.s3RoleArn,
        cfg.enableS3);

    // IMPORTANT: PipelineManager owns StreamSessions which call into AIEngine and
    // remove per-stream bins from the main pipeline during shutdown. Therefore,
    // PipelineManager must be destroyed BEFORE AIEngine::shutdown() and BEFORE
    // gst_object_unref(main_pipeline).
    auto pm = std::make_unique<PipelineManager>(
        main_pipeline, s3, cfg.rtpHost, cfg.metadataWSUrl, cfg.mediasoupServerUrl, cfg.outputDir,
        cfg.reconnectIntervalMs, cfg.maxReconnectAttempts);

    LOG_INFO("Main", "Initialized with RTP output to %s", cfg.rtpHost.c_str());
    LOG_INFO("Main", "Metadata will be sent to %s", cfg.metadataWSUrl.c_str());
    LOG_INFO("Main", "Mediasoup server at %s", cfg.mediasoupServerUrl.c_str());
    LOG_INFO("Main", "Recording output directory: %s", cfg.outputDir.c_str());
    LOG_INFO("Main", "Max streams: %d", cfg.maxStreams);
    LOG_INFO("Main", "Infer config: %s", cfg.inferConfigPath.c_str());
    LOG_INFO("Main", "Reconnect: interval=%dms, max_attempts=%d (0=unlimited)", 
             cfg.reconnectIntervalMs, cfg.maxReconnectAttempts);

    // Create HTTP server with port from config
    HTTPServer httpServer(*pm, cfg.httpPort);

    std::cout << "\n";
    std::cout << "==============================================\n";
    std::cout << "   AI Streaming Manager v3.0 (DeepStream)\n";
    std::cout << "==============================================\n";
    std::cout << "   HTTP API: http://0.0.0.0:" << cfg.httpPort << "\n";
    std::cout << "   RTP output: " << cfg.rtpHost << "\n";
    std::cout << "   Metadata WS: " << cfg.metadataWSUrl << "\n";
    std::cout << "   Max streams: " << cfg.maxStreams << "\n";
    std::cout << "   Log Level: " << cfg.logLevel << " | GST: " << cfg.gstLogLevel << "\n\n";
    std::cout << "   API Endpoints:\n";
    std::cout << "   POST   /api/stream                 - Create stream\n";
    std::cout << "   GET    /api/stream/:id             - Get stream info\n";
    std::cout << "   DELETE /api/stream/:id             - Delete stream\n";
    std::cout << "   GET    /api/streams                - List all streams\n";
    std::cout << "   POST   /api/stream/:id/start       - Start stream\n";
    std::cout << "   POST   /api/stream/:id/stop        - Stop stream\n";
    std::cout << "   POST   /api/stream/:id/record/start - Start recording\n";
    std::cout << "   POST   /api/stream/:id/record/stop  - Stop recording\n";
    std::cout << "   GET    /health                     - Health check\n";
    std::cout << "   GET    /api/info                   - System info\n";
    std::cout << "==============================================\n";
    std::cout << "   Press Ctrl+C to quit\n";
    std::cout << "==============================================\n\n";

    // Start HTTP server
    httpServer.start();

    // Start main pipeline
    gst_element_set_state(main_pipeline, GST_STATE_PLAYING);

    // Create and run GMainLoop in main thread (for all GStreamer pipelines)
    LOG_INFO("Main", "Starting GMainLoop");
    g_main_loop = g_main_loop_new(nullptr, FALSE);

    // Run main loop (blocking until quit)
    g_main_loop_run(g_main_loop);

    LOG_INFO("Main", "Main loop stopped, shutting down");

    // Graceful shutdown
    httpServer.stop();

    // Stop and clean up streams while AIEngine + main_pipeline are still alive
    pm.reset();

    // Stop pipeline
    gst_element_set_state(main_pipeline, GST_STATE_NULL);

    // Shutdown AI engine
    AIEngine::instance().shutdown();

    // Flush all metadata before exit
    if (s3)
    {
        LOG_INFO("Main", "Flushing all metadata before exit");
        s3->flushAllMetadata();
    }

    // Cleanup pipeline
    gst_object_unref(main_pipeline);

    // Cleanup GMainLoop
    g_main_loop_unref(g_main_loop);
    g_main_loop = nullptr;

    LOG_INFO("Main", "Shutdown complete. Goodbye!");
    return 0;
}
