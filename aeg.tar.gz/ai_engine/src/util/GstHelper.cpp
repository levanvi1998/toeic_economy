#include "GstHelper.h"
#include <iostream>

GstElement *GstHelper::createElement(const std::string &factory, const std::string &name)
{
    GstElement *elem = gst_element_factory_make(factory.c_str(),
                                                name.empty() ? nullptr : name.c_str());
    if (!elem)
    {
        std::cerr << "[ERROR] Failed to create element: " << factory << std::endl;
    }
    return elem;
}

void GstHelper::addAndSync(GstElement *pipeline, GstElement *element)
{
    if (!element)
        return;
    gst_bin_add(GST_BIN(pipeline), element);
    gst_element_sync_state_with_parent(element);
}

void GstHelper::addAndSyncMany(GstElement *pipeline, std::initializer_list<GstElement *> elements)
{
    for (auto *elem : elements)
    {
        addAndSync(pipeline, elem);
    }
}

bool GstHelper::linkPads(GstPad *src, GstPad *sink)
{
    GstPadLinkReturn ret = gst_pad_link(src, sink);
    return ret == GST_PAD_LINK_OK;
}

GstPad *GstHelper::getStaticPad(GstElement *element, const std::string &name)
{
    return gst_element_get_static_pad(element, name.c_str());
}

GstPad *GstHelper::requestPad(GstElement *element, const std::string &template_name)
{
    return gst_element_request_pad_simple(element, template_name.c_str());
}

bool GstHelper::isVideoCaps(GstCaps *caps)
{
    if (!caps)
        return false;
    const GstStructure *s = gst_caps_get_structure(caps, 0);
    return g_str_has_prefix(gst_structure_get_name(s), "video/");
}

bool GstHelper::isAudioCaps(GstCaps *caps)
{
    if (!caps)
        return false;
    const GstStructure *s = gst_caps_get_structure(caps, 0);
    return g_str_has_prefix(gst_structure_get_name(s), "audio/");
}

bool GstHelper::isH264Caps(GstCaps *caps)
{
    if (!caps)
        return false;
    const GstStructure *s = gst_caps_get_structure(caps, 0);
    return g_strcmp0(gst_structure_get_name(s), "video/x-h264") == 0;
}

bool GstHelper::isContainerCaps(GstCaps *caps)
{
    if (!caps)
        return false;
    std::string caps_str = getCapsString(caps);
    return caps_str.find("video/x-flv") != std::string::npos ||
           caps_str.find("video/mpegts") != std::string::npos ||
           caps_str.find("video/quicktime") != std::string::npos;
}

std::string GstHelper::getCapsString(GstCaps *caps)
{
    if (!caps)
        return "";
    gchar *str = gst_caps_to_string(caps);
    std::string ret(str);
    g_free(str);
    return ret;
}

GstElement *GstHelper::createQueue(const std::string &name, int max_buffers, bool leaky)
{
    GstElement *queue = createElement("queue", name);
    if (queue)
    {
        if (leaky)
        {
            g_object_set(queue, "leaky", 2, "max-size-buffers", 1, NULL);
        }
        else
        {
            g_object_set(queue, "max-size-buffers", max_buffers, NULL);
        }
    }
    return queue;
}

GstElement *GstHelper::createFakesink()
{
    GstElement *fakesink = createElement("fakesink");
    if (fakesink)
    {
        g_object_set(fakesink, "sync", FALSE, "async", FALSE, NULL);
    }
    return fakesink;
}

GstElement *GstHelper::createCapsFilter(const std::string &name, const std::string &caps_str)
{
    GstElement *capsf = createElement("capsfilter", name);
    if (capsf)
    {
        GstCaps *caps = gst_caps_from_string(caps_str.c_str());
        g_object_set(capsf, "caps", caps, NULL);
        gst_caps_unref(caps);
    }
    return capsf;
}

void GstHelper::linkToFakesink(GstElement *pipeline, GstPad *pad)
{
    GstElement *fakesink = createFakesink();
    addAndSync(pipeline, fakesink);

    GstPad *sink_pad = getStaticPad(fakesink, "sink");
    linkPads(pad, sink_pad);
    gst_object_unref(sink_pad);
}
