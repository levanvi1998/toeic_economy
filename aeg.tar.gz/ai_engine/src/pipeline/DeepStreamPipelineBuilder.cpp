/**
 * DeepStreamPipelineBuilder - Creates stream pipelines for DeepStream inference
 * 
 * Refactored for:
 * - Clean, maintainable code structure
 * - Shared encoder for RTP + Recording (avoids double encoding)
 * - Consistent use of helper functions
 */

#include "DeepStreamPipelineBuilder.h"
#include "VideoRecorder.h"
#include "ai/AIEngine.h"
#include "util/Logger.h"
#include "util/GstHelper.h"
#include <gst/gst.h>
#include <cstring>
#include <algorithm>

// ============================================================================
// Helper utilities
// ============================================================================

namespace {

const char* padLinkResultStr(GstPadLinkReturn ret) {
    switch (ret) {
        case GST_PAD_LINK_OK: return "OK";
        case GST_PAD_LINK_WRONG_HIERARCHY: return "WRONG_HIERARCHY";
        case GST_PAD_LINK_WAS_LINKED: return "WAS_LINKED";
        case GST_PAD_LINK_WRONG_DIRECTION: return "WRONG_DIRECTION";
        case GST_PAD_LINK_NOFORMAT: return "NOFORMAT";
        case GST_PAD_LINK_NOSCHED: return "NOSCHED";
        case GST_PAD_LINK_REFUSED: return "REFUSED";
        default: return "UNKNOWN";
    }
}

// Add element to bin and sync state
void addAndSync(GstElement* bin, GstElement* elem) {
    if (!elem) return;
    gst_bin_add(GST_BIN(bin), elem);
    gst_element_sync_state_with_parent(elem);
}

// Create element with optional name suffix
GstElement* createElement(const char* factory, const std::string& stream_id, const char* suffix = "") {
    std::string name = std::string(factory) + "_" + suffix + stream_id;
    return gst_element_factory_make(factory, name.c_str());
}

// Link tee to queue and return the queue
GstElement* linkTeeToQueue(GstElement* bin, GstElement* tee, const std::string& name, 
                           int max_buffers = 200, bool leaky = false) {
    GstElement* queue = gst_element_factory_make("queue", name.c_str());
    if (!queue) return nullptr;
    
    if (leaky) {
        g_object_set(queue, "max-size-buffers", 1, "leaky", 2, NULL);
    } else {
        g_object_set(queue, "max-size-buffers", max_buffers, NULL);
    }
    
    addAndSync(bin, queue);
    
    GstPad* tee_src = gst_element_request_pad_simple(tee, "src_%u");
    GstPad* q_sink = gst_element_get_static_pad(queue, "sink");
    gst_pad_link(tee_src, q_sink);
    gst_object_unref(q_sink);
    
    return queue;
}

// Get stream metadata stored in bin
struct StreamParams {
    std::string stream_id;
    std::string rtp_host;
    int rtp_port;
    int rtcp_port;
    unsigned int ssrc;
    VideoRecorder* recorder;
};

StreamParams getStreamParams(GstElement* stream_bin) {
    StreamParams p;
    const char* sid = (const char*)g_object_get_data(G_OBJECT(stream_bin), "stream-id");
    const char* host = (const char*)g_object_get_data(G_OBJECT(stream_bin), "rtp-host");
    p.stream_id = sid ? sid : "";
    p.rtp_host = host ? host : "";
    p.rtp_port = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(stream_bin), "rtp-port"));
    p.rtcp_port = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(stream_bin), "rtcp-port"));
    p.ssrc = GPOINTER_TO_UINT(g_object_get_data(G_OBJECT(stream_bin), "rtp-ssrc"));
    p.recorder = (VideoRecorder*)g_object_get_data(G_OBJECT(stream_bin), "recorder");
    return p;
}

} // anonymous namespace

// ============================================================================
// Stream type detection
// ============================================================================

DeepStreamPipelineBuilder::StreamType 
DeepStreamPipelineBuilder::detectStreamType(const std::string& uri)
{
    std::string lower = uri;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    
    if (lower.find("rtmp://") == 0) return StreamType::RTMP;
    if (lower.find("rtsp://") == 0) return StreamType::RTSP;
    if (lower.find("file://") == 0 || lower.find("/") == 0) return StreamType::FILE;
    
    return StreamType::OTHER;
}

// ============================================================================
// Caps detection helpers
// ============================================================================

bool DeepStreamPipelineBuilder::isVideoCaps(GstCaps* caps)
{
    if (!caps) return false;
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* name = gst_structure_get_name(s);
    return name && (g_str_has_prefix(name, "video/") || g_str_has_prefix(name, "image/"));
}

bool DeepStreamPipelineBuilder::isAudioCaps(GstCaps* caps)
{
    if (!caps) return false;
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* name = gst_structure_get_name(s);
    return name && g_str_has_prefix(name, "audio/");
}

bool DeepStreamPipelineBuilder::isH264Caps(GstCaps* caps)
{
    if (!caps) return false;
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* name = gst_structure_get_name(s);
    return name && (g_str_has_prefix(name, "video/x-h264") || 
                    g_str_has_prefix(name, "application/x-h264"));
}

bool DeepStreamPipelineBuilder::isH265Caps(GstCaps* caps)
{
    if (!caps) return false;
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* name = gst_structure_get_name(s);
    return name && (g_str_has_prefix(name, "video/x-h265") || 
                    g_str_has_prefix(name, "video/x-hevc"));
}

void DeepStreamPipelineBuilder::linkToFakesink(GstElement* bin, GstPad* pad)
{
    GstElement* fakesink = gst_element_factory_make("fakesink", NULL);
    g_object_set(fakesink, "sync", FALSE, "async", FALSE, NULL);
    addAndSync(bin, fakesink);
    
    GstPad* sink = gst_element_get_static_pad(fakesink, "sink");
    gst_pad_link(pad, sink);
    gst_object_unref(sink);
}

// ============================================================================
// Main build function
// ============================================================================

GstElement* DeepStreamPipelineBuilder::build(GstElement* main_pipeline,
                                             const std::string& stream_id,
                                             const std::string& uri,
                                             const std::string& rtp_host,
                                             int rtp_port,
                                             int rtcp_port,
                                             unsigned int ssrc,
                                             const std::string& output_dir,
                                             VideoRecorder* recorder)
{
    StreamType type = detectStreamType(uri);
    const char* type_str = (type == StreamType::RTMP) ? "RTMP" : 
                           (type == StreamType::RTSP) ? "RTSP" : 
                           (type == StreamType::FILE) ? "FILE" : "OTHER";
    
    LOG_INFO("PipelineBuilder", "[%s] Building %s pipeline: %s", 
             stream_id.c_str(), type_str, uri.c_str());

    // Create stream bin
    GstElement* stream_bin = gst_bin_new(("streambin_" + stream_id).c_str());
    if (!stream_bin) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create stream bin", stream_id.c_str());
        return nullptr;
    }

    // Store metadata in bin for callbacks
    g_object_set_data_full(G_OBJECT(stream_bin), "stream-id", g_strdup(stream_id.c_str()), g_free);
    g_object_set_data_full(G_OBJECT(stream_bin), "rtp-host", g_strdup(rtp_host.c_str()), g_free);
    g_object_set_data(G_OBJECT(stream_bin), "rtp-port", GINT_TO_POINTER(rtp_port));
    g_object_set_data(G_OBJECT(stream_bin), "rtcp-port", GINT_TO_POINTER(rtcp_port));
    g_object_set_data(G_OBJECT(stream_bin), "rtp-ssrc", GUINT_TO_POINTER(ssrc));
    g_object_set_data_full(G_OBJECT(stream_bin), "output-dir", g_strdup(output_dir.c_str()), g_free);
    g_object_set_data(G_OBJECT(stream_bin), "recorder", recorder);
    g_object_set_data(G_OBJECT(stream_bin), "stream-type", GINT_TO_POINTER((int)type));

    // Build source based on stream type
    if (type == StreamType::RTSP) {
        buildRTSPSource(stream_bin, stream_id, uri);
    } else if (type == StreamType::RTMP) {
        buildRTMPSource(stream_bin, stream_id, uri);
    } else {
        buildGenericSource(stream_bin, stream_id, uri);
    }

    // Add bin to main pipeline
    gst_bin_add(GST_BIN(main_pipeline), stream_bin);
    
    LOG_INFO("PipelineBuilder", "[%s] Pipeline created", stream_id.c_str());
    return stream_bin;
}

// ============================================================================
// Source builders
// ============================================================================

void DeepStreamPipelineBuilder::buildRTSPSource(GstElement* stream_bin, 
                                                 const std::string& stream_id, 
                                                 const std::string& uri)
{
    // Use urisourcebin for RTSP - outputs encoded H264/H265 (no decoding)
    // This avoids decode->encode round-trip for RTP/Record branches
    GstElement* src = gst_element_factory_make("urisourcebin", ("src_" + stream_id).c_str());
    if (!src) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create urisourcebin", stream_id.c_str());
        return;
    }
    
    g_object_set(src, "uri", uri.c_str(), NULL);
    gst_bin_add(GST_BIN(stream_bin), src);
    
    // Store references for callback
    g_object_set_data(G_OBJECT(src), "stream-bin", stream_bin);
    g_object_set_data_full(G_OBJECT(src), "stream-id", g_strdup(stream_id.c_str()), g_free);
    
    // Connect pad-added signal - will receive RTP or encoded video pads
    g_signal_connect(src, "pad-added", G_CALLBACK(onSourcePadAdded), NULL);
    
    LOG_INFO("PipelineBuilder", "[%s] RTSP source created with urisourcebin (no decode)", stream_id.c_str());
}

void DeepStreamPipelineBuilder::buildRTMPSource(GstElement* stream_bin, 
                                                 const std::string& stream_id, 
                                                 const std::string& uri)
{
    // RTMP: urisourcebin -> queue -> flvdemux
    GstElement* src = gst_element_factory_make("urisourcebin", ("src_" + stream_id).c_str());
    GstElement* queue = gst_element_factory_make("queue", ("queue_src_" + stream_id).c_str());
    GstElement* demux = gst_element_factory_make("flvdemux", ("flvdemux_" + stream_id).c_str());
    
    if (!src || !queue || !demux) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create RTMP elements", stream_id.c_str());
        return;
    }
    
    g_object_set(src, "uri", uri.c_str(), NULL);
    g_object_set(queue, "max-size-buffers", 200, "max-size-bytes", 10485760, 
                 "max-size-time", (guint64)5000000000, NULL);
    
    gst_bin_add_many(GST_BIN(stream_bin), src, queue, demux, NULL);
    gst_element_link(queue, demux);
    
    // Store references
    g_object_set_data(G_OBJECT(src), "stream-bin", stream_bin);
    g_object_set_data_full(G_OBJECT(src), "stream-id", g_strdup(stream_id.c_str()), g_free);
    g_object_set_data(G_OBJECT(src), "target-queue", queue);
    g_object_set_data(G_OBJECT(demux), "stream-bin", stream_bin);
    g_object_set_data_full(G_OBJECT(demux), "stream-id", g_strdup(stream_id.c_str()), g_free);
    
    g_signal_connect(src, "pad-added", G_CALLBACK(onSourcePadAdded), NULL);
    g_signal_connect(demux, "pad-added", G_CALLBACK(onDemuxPadAdded), NULL);
    
    LOG_INFO("PipelineBuilder", "[%s] RTMP source created", stream_id.c_str());
}

void DeepStreamPipelineBuilder::buildGenericSource(GstElement* stream_bin, 
                                                    const std::string& stream_id, 
                                                    const std::string& uri)
{
    GstElement* src = gst_element_factory_make("urisourcebin", ("src_" + stream_id).c_str());
    if (!src) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create urisourcebin", stream_id.c_str());
        return;
    }
    
    g_object_set(src, "uri", uri.c_str(), NULL);
    gst_bin_add(GST_BIN(stream_bin), src);
    
    g_object_set_data(G_OBJECT(src), "stream-bin", stream_bin);
    g_object_set_data_full(G_OBJECT(src), "stream-id", g_strdup(stream_id.c_str()), g_free);
    
    g_signal_connect(src, "pad-added", G_CALLBACK(onSourcePadAdded), NULL);
    
    LOG_INFO("PipelineBuilder", "[%s] Generic source created", stream_id.c_str());
}

// ============================================================================
// Callback: uridecodebin pad-added (outputs decoded video/x-raw)
// ============================================================================

void DeepStreamPipelineBuilder::onUriDecodePadAdded(GstElement* src, GstPad* pad, gpointer)
{
    char* stream_id = (char*)g_object_get_data(G_OBJECT(src), "stream-id");
    GstElement* stream_bin = (GstElement*)g_object_get_data(G_OBJECT(src), "stream-bin");
    
    if (!stream_id || !stream_bin) return;
    
    GstCaps* caps = gst_pad_get_current_caps(pad);
    if (!caps) caps = gst_pad_query_caps(pad, NULL);
    if (!caps) return;
    
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* media_type = gst_structure_get_name(s);
    
    // Skip if video branch already built
    if (g_object_get_data(G_OBJECT(stream_bin), "video-branch-built")) {
        gst_caps_unref(caps);
        return;
    }
    
    if (g_str_has_prefix(media_type, "video/x-raw")) {
        LOG_INFO("PipelineBuilder", "[%s] Got decoded video pad", stream_id);
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        buildVideoBranchRaw(stream_bin, stream_id, pad);
    } else if (g_str_has_prefix(media_type, "video/")) {
        LOG_INFO("PipelineBuilder", "[%s] Got encoded video pad", stream_id);
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        buildVideoBranch(stream_bin, stream_id, pad, isH264Caps(caps));
    } else if (g_str_has_prefix(media_type, "audio/")) {
        linkToFakesink(stream_bin, pad);
    }
    
    gst_caps_unref(caps);
}

// ============================================================================
// Callback: Source pad added (from urisourcebin)
// ============================================================================

void DeepStreamPipelineBuilder::onSourcePadAdded(GstElement* src, GstPad* pad, gpointer)
{
    char* stream_id = (char*)g_object_get_data(G_OBJECT(src), "stream-id");
    GstElement* stream_bin = (GstElement*)g_object_get_data(G_OBJECT(src), "stream-bin");
    GstElement* target_queue = (GstElement*)g_object_get_data(G_OBJECT(src), "target-queue");
    
    if (!stream_id || !stream_bin) return;
    if (gst_pad_is_linked(pad)) return;

    GstCaps* caps = gst_pad_get_current_caps(pad);
    if (!caps) caps = gst_pad_query_caps(pad, NULL);
    if (!caps) return;
    
    GstStructure* s = gst_caps_get_structure(caps, 0);
    const gchar* media_type = gst_structure_get_name(s);
    
    LOG_INFO("PipelineBuilder", "[%s] Source pad: %s", stream_id, media_type);

    // RTMP mode: link to queue (flvdemux handles the rest)
    if (target_queue) {
        GstPad* queue_sink = gst_element_get_static_pad(target_queue, "sink");
        if (queue_sink && !gst_pad_is_linked(queue_sink)) {
            gst_pad_link(pad, queue_sink);
            LOG_INFO("PipelineBuilder", "[%s] Linked to RTMP queue", stream_id);
        }
        if (queue_sink) gst_object_unref(queue_sink);
        gst_caps_unref(caps);
        return;
    }
    
    // Skip if video branch already built
    if (g_object_get_data(G_OBJECT(stream_bin), "video-branch-built")) {
        if (!g_str_has_prefix(media_type, "video/")) {
            linkToFakesink(stream_bin, pad);
        }
        gst_caps_unref(caps);
        return;
    }
    
    // Handle RTP streams (from RTSP via urisourcebin)
    if (g_str_has_prefix(media_type, "application/x-rtp")) {
        const gchar* media = gst_structure_get_string(s, "media");
        const gchar* encoding = gst_structure_get_string(s, "encoding-name");
        
        LOG_INFO("PipelineBuilder", "[%s] RTP: media=%s, encoding=%s", 
                 stream_id, media ? media : "?", encoding ? encoding : "?");
        
        // Skip non-video RTP
        if (!media || g_strcmp0(media, "video") != 0) {
            linkToFakesink(stream_bin, pad);
            gst_caps_unref(caps);
            return;
        }
        
        bool is_h264 = (encoding && g_strcmp0(encoding, "H264") == 0);
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        
        if (is_h264) {
            // H264: Keep as-is, no re-encode needed
            GstElement* depay = gst_element_factory_make("rtph264depay", ("depay_" + std::string(stream_id)).c_str());
            GstElement* parse = gst_element_factory_make("h264parse", ("parse_" + std::string(stream_id)).c_str());
            
            if (!depay || !parse) {
                LOG_ERROR("PipelineBuilder", "[%s] Failed to create H264 depay/parse", stream_id);
                gst_caps_unref(caps);
                return;
            }
            
            addAndSync(stream_bin, depay);
            addAndSync(stream_bin, parse);
            
            GstPad* depay_sink = gst_element_get_static_pad(depay, "sink");
            gst_pad_link(pad, depay_sink);
            gst_object_unref(depay_sink);
            gst_element_link(depay, parse);
            
            GstPad* src_pad = gst_element_get_static_pad(parse, "src");
            buildVideoBranch(stream_bin, stream_id, src_pad, true);
            gst_object_unref(src_pad);
            
            LOG_INFO("PipelineBuilder", "[%s] H264 RTP - keeping encoded stream", stream_id);
        } else {
            // H265/other: Decode and re-encode to H264 for compatibility
            bool is_h265 = (encoding && (g_strcmp0(encoding, "H265") == 0 || g_strcmp0(encoding, "HEVC") == 0));
            
            GstElement* depay = nullptr;
            GstElement* parse = nullptr;
            
            if (is_h265) {
                depay = gst_element_factory_make("rtph265depay", ("depay_" + std::string(stream_id)).c_str());
                parse = gst_element_factory_make("h265parse", ("parse_" + std::string(stream_id)).c_str());
            } else {
                // Try H264 as fallback
                LOG_WARN("PipelineBuilder", "[%s] Unknown RTP encoding '%s', trying H264", stream_id, encoding ? encoding : "?");
                depay = gst_element_factory_make("rtph264depay", ("depay_" + std::string(stream_id)).c_str());
                parse = gst_element_factory_make("h264parse", ("parse_" + std::string(stream_id)).c_str());
            }
            
            GstElement* decoder = gst_element_factory_make("nvv4l2decoder", ("dec_" + std::string(stream_id)).c_str());
            
            if (!depay || !parse || !decoder) {
                LOG_ERROR("PipelineBuilder", "[%s] Failed to create decode pipeline", stream_id);
                gst_caps_unref(caps);
                return;
            }
            
            addAndSync(stream_bin, depay);
            addAndSync(stream_bin, parse);
            addAndSync(stream_bin, decoder);
            
            GstPad* depay_sink = gst_element_get_static_pad(depay, "sink");
            gst_pad_link(pad, depay_sink);
            gst_object_unref(depay_sink);
            
            gst_element_link_many(depay, parse, decoder, NULL);
            
            GstPad* dec_src = gst_element_get_static_pad(decoder, "src");
            buildVideoBranchRaw(stream_bin, stream_id, dec_src);
            gst_object_unref(dec_src);
            
            LOG_INFO("PipelineBuilder", "[%s] %s RTP - decode and re-encode to H264", 
                     stream_id, is_h265 ? "H265" : "Unknown");
        }
        
        gst_caps_unref(caps);
        return;
    }
    
    // Handle audio
    if (g_str_has_prefix(media_type, "audio/")) {
        linkToFakesink(stream_bin, pad);
        gst_caps_unref(caps);
        return;
    }
    
    // Handle decoded video (from uridecodebin if used)
    if (g_str_has_prefix(media_type, "video/x-raw")) {
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        buildVideoBranchRaw(stream_bin, stream_id, pad);
        gst_caps_unref(caps);
        return;
    }
    
    // Handle encoded video (H264 keep, others decode and re-encode to H264)
    if (isVideoCaps(caps)) {
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        
        if (isH264Caps(caps)) {
            // H264: Keep as-is
            buildVideoBranch(stream_bin, stream_id, pad, true);
            LOG_INFO("PipelineBuilder", "[%s] H264 stream - keeping encoded", stream_id);
        } else {
            // H265/other: Decode and re-encode to H264
            GstElement* parse = gst_element_factory_make("h265parse", ("parse_" + std::string(stream_id)).c_str());
            GstElement* decoder = gst_element_factory_make("nvv4l2decoder", ("dec_" + std::string(stream_id)).c_str());
            
            if (!parse || !decoder) {
                LOG_ERROR("PipelineBuilder", "[%s] Failed to create H265 decode pipeline", stream_id);
                gst_caps_unref(caps);
                return;
            }
            
            addAndSync(stream_bin, parse);
            addAndSync(stream_bin, decoder);
            
            GstPad* parse_sink = gst_element_get_static_pad(parse, "sink");
            gst_pad_link(pad, parse_sink);
            gst_object_unref(parse_sink);
            
            gst_element_link(parse, decoder);
            
            GstPad* dec_src = gst_element_get_static_pad(decoder, "src");
            buildVideoBranchRaw(stream_bin, stream_id, dec_src);
            gst_object_unref(dec_src);
            
            LOG_INFO("PipelineBuilder", "[%s] H265 stream - decode and re-encode to H264", stream_id);
        }
        gst_caps_unref(caps);
        return;
    }
    
    // Unknown -> fakesink
    LOG_WARN("PipelineBuilder", "[%s] Unknown media type: %s", stream_id, media_type);
    linkToFakesink(stream_bin, pad);
    gst_caps_unref(caps);
}

// ============================================================================
// Callback: Demux pad added (from flvdemux for RTMP)
// ============================================================================

void DeepStreamPipelineBuilder::onDemuxPadAdded(GstElement* demux, GstPad* pad, gpointer)
{
    char* stream_id = (char*)g_object_get_data(G_OBJECT(demux), "stream-id");
    GstElement* stream_bin = (GstElement*)g_object_get_data(G_OBJECT(demux), "stream-bin");
    
    if (!stream_id || !stream_bin) return;
    if (g_object_get_data(G_OBJECT(stream_bin), "video-branch-built")) return;
    
    GstCaps* caps = gst_pad_get_current_caps(pad);
    if (!caps) {
        // Wait for caps
        g_object_set_data_full(G_OBJECT(pad), "stream-id", g_strdup(stream_id), g_free);
        g_object_set_data(G_OBJECT(pad), "stream-bin", stream_bin);
        g_signal_connect(pad, "notify::caps", G_CALLBACK(onCapsChanged), NULL);
        return;
    }
    
    if (isAudioCaps(caps)) {
        linkToFakesink(stream_bin, pad);
    } else if (isVideoCaps(caps)) {
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        
        if (isH264Caps(caps)) {
            // H264: Keep as-is
            buildVideoBranch(stream_bin, stream_id, pad, true);
        } else {
            // H265/other: Decode and re-encode to H264
            GstElement* parse = gst_element_factory_make("h265parse", ("parse_" + std::string(stream_id)).c_str());
            GstElement* decoder = gst_element_factory_make("nvv4l2decoder", ("dec_" + std::string(stream_id)).c_str());
            
            if (parse && decoder) {
                addAndSync(stream_bin, parse);
                addAndSync(stream_bin, decoder);
                
                GstPad* parse_sink = gst_element_get_static_pad(parse, "sink");
                gst_pad_link(pad, parse_sink);
                gst_object_unref(parse_sink);
                
                gst_element_link(parse, decoder);
                
                GstPad* dec_src = gst_element_get_static_pad(decoder, "src");
                buildVideoBranchRaw(stream_bin, stream_id, dec_src);
                gst_object_unref(dec_src);
            }
        }
    }
    
    gst_caps_unref(caps);
}

// ============================================================================
// Callback: Caps changed (delayed caps negotiation)
// ============================================================================

void DeepStreamPipelineBuilder::onCapsChanged(GstPad* pad, GParamSpec*, gpointer)
{
    char* stream_id = (char*)g_object_get_data(G_OBJECT(pad), "stream-id");
    GstElement* stream_bin = (GstElement*)g_object_get_data(G_OBJECT(pad), "stream-bin");
    
    GstCaps* caps = gst_pad_get_current_caps(pad);
    if (!caps) return;
    
    g_signal_handlers_disconnect_by_func(pad, (gpointer)onCapsChanged, NULL);
    
    if (g_object_get_data(G_OBJECT(stream_bin), "video-branch-built")) {
        gst_caps_unref(caps);
        return;
    }
    
    if (isAudioCaps(caps)) {
        linkToFakesink(stream_bin, pad);
    } else if (isVideoCaps(caps)) {
        GstStructure* s = gst_caps_get_structure(caps, 0);
        const gchar* name = gst_structure_get_name(s);
        bool is_raw = (name && g_str_has_prefix(name, "video/x-raw"));
        
        g_object_set_data(G_OBJECT(stream_bin), "video-branch-built", GINT_TO_POINTER(1));
        
        if (is_raw) {
            buildVideoBranchRaw(stream_bin, stream_id ? stream_id : "", pad);
        } else if (isH264Caps(caps)) {
            // H264: Keep as-is
            buildVideoBranch(stream_bin, stream_id ? stream_id : "", pad, true);
        } else {
            // H265/other: Decode and re-encode to H264
            std::string sid = stream_id ? stream_id : "";
            GstElement* parse = gst_element_factory_make("h265parse", ("parse_" + sid).c_str());
            GstElement* decoder = gst_element_factory_make("nvv4l2decoder", ("dec_" + sid).c_str());
            
            if (parse && decoder) {
                addAndSync(stream_bin, parse);
                addAndSync(stream_bin, decoder);
                
                GstPad* parse_sink = gst_element_get_static_pad(parse, "sink");
                gst_pad_link(pad, parse_sink);
                gst_object_unref(parse_sink);
                
                gst_element_link(parse, decoder);
                
                GstPad* dec_src = gst_element_get_static_pad(decoder, "src");
                buildVideoBranchRaw(stream_bin, sid.c_str(), dec_src);
                gst_object_unref(dec_src);
            }
        }
    }
    
    gst_caps_unref(caps);
}

// ============================================================================
// Build video branch for ENCODED video (H264/H265)
// Pipeline: src -> queue -> tee -> [AI branch, RTP branch, Record branch]
// ============================================================================

void DeepStreamPipelineBuilder::buildVideoBranch(GstElement* stream_bin,
                                                  const std::string& stream_id,
                                                  GstPad* src_pad,
                                                  bool is_h264)
{
    LOG_INFO("PipelineBuilder", "[%s] Building encoded video branch (H264: %s)", 
             stream_id.c_str(), is_h264 ? "yes" : "no");

    StreamParams params = getStreamParams(stream_bin);

    // Input queue -> tee
    GstElement* q_in = gst_element_factory_make("queue", ("q_in_" + stream_id).c_str());
    GstElement* tee = gst_element_factory_make("tee", ("tee_" + stream_id).c_str());
    
    g_object_set(q_in, "max-size-buffers", 200, NULL);
    addAndSync(stream_bin, q_in);
    addAndSync(stream_bin, tee);
    
    // Link src -> queue -> tee
    GstPad* q_sink = gst_element_get_static_pad(q_in, "sink");
    if (gst_pad_link(src_pad, q_sink) != GST_PAD_LINK_OK) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to link src -> queue", stream_id.c_str());
        gst_object_unref(q_sink);
        return;
    }
    gst_object_unref(q_sink);
    gst_element_link(q_in, tee);

    // Create branches
    createAIBranch(stream_bin, stream_id, tee, is_h264);
    createRTPBranch(stream_bin, stream_id, tee, is_h264, params);
    createRecordBranch(stream_bin, stream_id, tee);

    LOG_INFO("PipelineBuilder", "[%s] Encoded video branch complete", stream_id.c_str());
}

// ============================================================================
// Build video branch for RAW decoded video (from uridecodebin)
// OPTIMIZED: Single shared encoder for RTP + Recording
// Pipeline: src -> tee -> [AI branch (raw), Shared encoder -> tee2 -> [RTP, Record]]
// ============================================================================

void DeepStreamPipelineBuilder::buildVideoBranchRaw(GstElement* stream_bin,
                                                     const std::string& stream_id,
                                                     GstPad* src_pad)
{
    LOG_INFO("PipelineBuilder", "[%s] Building RAW video branch with shared encoder", stream_id.c_str());

    StreamParams params = getStreamParams(stream_bin);
    bool need_rtp = !params.rtp_host.empty() && params.rtp_port > 0;
    bool need_record = params.recorder != nullptr;

    // Input queue -> tee (splits raw video)
    GstElement* q_in = gst_element_factory_make("queue", ("q_in_" + stream_id).c_str());
    GstElement* tee_raw = gst_element_factory_make("tee", ("tee_raw_" + stream_id).c_str());
    
    g_object_set(q_in, "max-size-buffers", 200, NULL);
    addAndSync(stream_bin, q_in);
    addAndSync(stream_bin, tee_raw);
    
    // Link src -> queue -> tee
    GstPad* q_sink = gst_element_get_static_pad(q_in, "sink");
    if (gst_pad_link(src_pad, q_sink) != GST_PAD_LINK_OK) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to link src -> queue", stream_id.c_str());
        gst_object_unref(q_sink);
        return;
    }
    gst_object_unref(q_sink);
    gst_element_link(q_in, tee_raw);

    // AI branch (directly from raw video, no encoding needed)
    createAIBranchRaw(stream_bin, stream_id, tee_raw);
    
    // Shared encoder branch (only if RTP or Record needed)
    if (need_rtp || need_record) {
        createSharedEncoderBranch(stream_bin, stream_id, tee_raw, params);
    }

    LOG_INFO("PipelineBuilder", "[%s] RAW video branch complete", stream_id.c_str());
}

// ============================================================================
// AI Branch: tee -> queue -> parse -> decode -> convert -> nvstreammux
// ============================================================================

void DeepStreamPipelineBuilder::createAIBranch(GstElement* stream_bin,
                                                const std::string& stream_id,
                                                GstElement* tee,
                                                bool is_h264)
{
    LOG_INFO("PipelineBuilder", "[%s] Creating AI branch", stream_id.c_str());

    // Leaky queue for AI (drop old frames if processing is slow)
    GstElement* q_ai = linkTeeToQueue(stream_bin, tee, "q_ai_" + stream_id, 1, true);
    if (!q_ai) return;

    GstElement* last_elem = q_ai;

    if (is_h264) {
        // H264: parse -> decode -> convert -> capsfilter
        GstElement* parse = createElement("h264parse", stream_id, "parse_ai_");
        GstElement* decoder = createElement("nvv4l2decoder", stream_id, "dec_");
        GstElement* conv = createElement("nvvideoconvert", stream_id, "conv_ai_");
        GstElement* capsf = createElement("capsfilter", stream_id, "capsf_ai_");

        if (!parse || !decoder || !conv || !capsf) {
            LOG_ERROR("PipelineBuilder", "[%s] Failed to create AI decode elements", stream_id.c_str());
            return;
        }

        GstCaps* caps = gst_caps_from_string("video/x-raw(memory:NVMM),format=NV12");
        g_object_set(capsf, "caps", caps, NULL);
        gst_caps_unref(caps);

        addAndSync(stream_bin, parse);
        addAndSync(stream_bin, decoder);
        addAndSync(stream_bin, conv);
        addAndSync(stream_bin, capsf);
        
        gst_element_link_many(q_ai, parse, decoder, conv, capsf, NULL);
        last_elem = capsf;
    } else {
        // Non-H264: convert -> capsfilter
        GstElement* conv = createElement("nvvideoconvert", stream_id, "conv_ai_");
        GstElement* capsf = createElement("capsfilter", stream_id, "capsf_ai_");

        GstCaps* caps = gst_caps_from_string("video/x-raw(memory:NVMM),format=NV12");
        g_object_set(capsf, "caps", caps, NULL);
        gst_caps_unref(caps);

        addAndSync(stream_bin, conv);
        addAndSync(stream_bin, capsf);
        gst_element_link_many(q_ai, conv, capsf, NULL);
        last_elem = capsf;
    }

    // Link to AIEngine nvstreammux
    linkToAIEngine(stream_bin, stream_id, last_elem);
}

// ============================================================================
// AI Branch for RAW video: tee -> queue -> nvvideoconvert -> capsfilter -> mux
// ============================================================================

void DeepStreamPipelineBuilder::createAIBranchRaw(GstElement* stream_bin,
                                                   const std::string& stream_id,
                                                   GstElement* tee)
{
    LOG_INFO("PipelineBuilder", "[%s] Creating AI branch (RAW)", stream_id.c_str());

    GstElement* q_ai = linkTeeToQueue(stream_bin, tee, "q_ai_" + stream_id, 1, true);
    if (!q_ai) return;

    // nvvideoconvert handles both CPU and GPU memory
    GstElement* conv = createElement("nvvideoconvert", stream_id, "conv_ai_");
    GstElement* capsf = createElement("capsfilter", stream_id, "capsf_ai_");

    if (!conv || !capsf) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create AI convert elements", stream_id.c_str());
        return;
    }

    GstCaps* caps = gst_caps_from_string("video/x-raw(memory:NVMM),format=NV12");
    g_object_set(capsf, "caps", caps, NULL);
    gst_caps_unref(caps);

    addAndSync(stream_bin, conv);
    addAndSync(stream_bin, capsf);
    gst_element_link_many(q_ai, conv, capsf, NULL);

    linkToAIEngine(stream_bin, stream_id, capsf);
}

// ============================================================================
// Link capsfilter to AIEngine nvstreammux
// ============================================================================

// EOS probe callback - called when stream sends EOS to nvstreammux
static GstPadProbeReturn onEOSProbe(GstPad* pad, GstPadProbeInfo* info, gpointer user_data)
{
    if (GST_EVENT_TYPE(GST_PAD_PROBE_INFO_DATA(info)) == GST_EVENT_EOS) {
        char* stream_id = (char*)user_data;
        if (stream_id) {
            LOG_WARN("PipelineBuilder", "[%s] EOS detected on AI branch - source ended", stream_id);
            
            // Post a custom message to the bus to trigger reconnect
            GstElement* stream_bin = GST_ELEMENT(gst_pad_get_parent(pad));
            if (stream_bin) {
                GstElement* pipeline = stream_bin;
                while (GST_ELEMENT_PARENT(pipeline)) {
                    pipeline = GST_ELEMENT_PARENT(pipeline);
                }
                
                if (pipeline) {
                    // Create a custom message that StreamSession can detect
                    GstStructure* s = gst_structure_new("stream-eos",
                        "stream-id", G_TYPE_STRING, stream_id,
                        NULL);
                    GstMessage* msg = gst_message_new_application(GST_OBJECT(stream_bin), s);
                    gst_element_post_message(pipeline, msg);
                }
                gst_object_unref(stream_bin);
            }
        }
    }
    return GST_PAD_PROBE_OK;
}

void DeepStreamPipelineBuilder::linkToAIEngine(GstElement* stream_bin,
                                                const std::string& stream_id,
                                                GstElement* last_elem)
{
    GstPad* capsf_src = gst_element_get_static_pad(last_elem, "src");
    GstPad* mux_sink = AIEngine::instance().requestSinkPad(stream_id);
    
    if (!mux_sink) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to get AIEngine sink pad", stream_id.c_str());
        gst_object_unref(capsf_src);
        return;
    }

    GstPadLinkReturn ret = gst_pad_link(capsf_src, mux_sink);
    GstPad* probe_pad = capsf_src;
    
    if (ret != GST_PAD_LINK_OK) {
        // Create ghost pad for cross-bin linking
        std::string ghost_name = "video_src_" + stream_id;
        GstPad* ghost = gst_ghost_pad_new(ghost_name.c_str(), capsf_src);
        gst_element_add_pad(stream_bin, ghost);
        gst_pad_set_active(ghost, TRUE);
        
        ret = gst_pad_link(ghost, mux_sink);
        probe_pad = ghost;
        
        if (ret != GST_PAD_LINK_OK) {
            LOG_ERROR("PipelineBuilder", "[%s] Failed to link to AIEngine: %s", 
                     stream_id.c_str(), padLinkResultStr(ret));
        } else {
            LOG_INFO("PipelineBuilder", "[%s] Linked to AIEngine via ghost pad", stream_id.c_str());
        }
    } else {
        LOG_INFO("PipelineBuilder", "[%s] Linked to AIEngine", stream_id.c_str());
    }
    
    // Add EOS probe to detect when stream ends
    char* sid = g_strdup(stream_id.c_str());
    gst_pad_add_probe(probe_pad, GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM,
                      onEOSProbe, sid, g_free);
    
    gst_object_unref(mux_sink);
    gst_object_unref(capsf_src);
}

// ============================================================================
// Shared encoder branch for RAW video (encode once, use for RTP + Record)
// Pipeline: tee -> queue -> nvvideoconvert -> encoder -> tee -> [RTP, Record]
// ============================================================================

void DeepStreamPipelineBuilder::createSharedEncoderBranch(GstElement* stream_bin,
                                                           const std::string& stream_id,
                                                           GstElement* tee_raw,
                                                           const StreamParams& params)
{
    LOG_INFO("PipelineBuilder", "[%s] Creating shared encoder branch", stream_id.c_str());

    // Queue from raw tee
    GstElement* q_enc = linkTeeToQueue(stream_bin, tee_raw, "q_enc_" + stream_id, 200, false);
    if (!q_enc) return;

    // Convert and encode
    GstElement* conv = createElement("nvvideoconvert", stream_id, "conv_enc_");
    GstElement* encoder = createElement("nvv4l2h264enc", stream_id, "enc_");
    GstElement* parse = createElement("h264parse", stream_id, "parse_enc_");
    GstElement* tee_h264 = gst_element_factory_make("tee", ("tee_h264_" + stream_id).c_str());

    if (!conv || !encoder || !parse || !tee_h264) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create encoder elements", stream_id.c_str());
        return;
    }

    // Configure encoder
    g_object_set(encoder,
                 "bitrate", 4000000,
                 "iframeinterval", 30,
                 "preset-level", 1,  // UltraFast
                 NULL);

    addAndSync(stream_bin, conv);
    addAndSync(stream_bin, encoder);
    addAndSync(stream_bin, parse);
    addAndSync(stream_bin, tee_h264);

    gst_element_link_many(q_enc, conv, encoder, parse, tee_h264, NULL);

    // Create RTP branch from encoded tee
    if (!params.rtp_host.empty() && params.rtp_port > 0) {
        createRTPBranchFromH264(stream_bin, stream_id, tee_h264, params);
    }

    // Create Record branch from encoded tee
    if (params.recorder) {
        createRecordBranchFromH264(stream_bin, stream_id, tee_h264, params.recorder);
    }

    LOG_INFO("PipelineBuilder", "[%s] Shared encoder branch complete", stream_id.c_str());
}

// ============================================================================
// RTP Branch (for encoded video): tee -> queue -> parse -> pay -> udpsink
// ============================================================================

void DeepStreamPipelineBuilder::createRTPBranch(GstElement* stream_bin,
                                                 const std::string& stream_id,
                                                 GstElement* tee,
                                                 bool is_h264,
                                                 const StreamParams& params)
{
    if (params.rtp_host.empty() || params.rtp_port <= 0) {
        return;
    }

    LOG_INFO("PipelineBuilder", "[%s] Creating RTP branch -> %s:%d", 
             stream_id.c_str(), params.rtp_host.c_str(), params.rtp_port);

    GstElement* q_rtp = linkTeeToQueue(stream_bin, tee, "q_rtp_" + stream_id, 200, false);
    if (!q_rtp) return;

    GstElement* encoder = nullptr;
    if (!is_h264) {
        encoder = createElement("nvv4l2h264enc", stream_id, "enc_rtp_");
        g_object_set(encoder, "bitrate", 4000000, "iframeinterval", 30, "preset-level", 1, NULL);
        addAndSync(stream_bin, encoder);
    }

    GstElement* parse = createElement("h264parse", stream_id, "parse_rtp_");
    GstElement* pay = createElement("rtph264pay", stream_id, "pay_");
    GstElement* udpsink = createElement("udpsink", stream_id, "udpsink_");

    g_object_set(pay, "config-interval", 1, "pt", 96, "ssrc", params.ssrc, NULL);
    g_object_set(udpsink, "host", params.rtp_host.c_str(), "port", params.rtp_port, "sync", FALSE, NULL);

    addAndSync(stream_bin, parse);
    addAndSync(stream_bin, pay);
    addAndSync(stream_bin, udpsink);

    if (encoder) {
        gst_element_link_many(q_rtp, encoder, parse, pay, udpsink, NULL);
    } else {
        gst_element_link_many(q_rtp, parse, pay, udpsink, NULL);
    }

    LOG_INFO("PipelineBuilder", "[%s] RTP branch created", stream_id.c_str());
}

// ============================================================================
// RTP Branch from H264 tee: tee -> queue -> pay -> udpsink
// ============================================================================

void DeepStreamPipelineBuilder::createRTPBranchFromH264(GstElement* stream_bin,
                                                         const std::string& stream_id,
                                                         GstElement* tee_h264,
                                                         const StreamParams& params)
{
    LOG_INFO("PipelineBuilder", "[%s] Creating RTP branch from shared encoder -> %s:%d", 
             stream_id.c_str(), params.rtp_host.c_str(), params.rtp_port);

    GstElement* q_rtp = linkTeeToQueue(stream_bin, tee_h264, "q_rtp_" + stream_id, 200, false);
    if (!q_rtp) return;

    GstElement* pay = createElement("rtph264pay", stream_id, "pay_");
    GstElement* udpsink = createElement("udpsink", stream_id, "udpsink_");

    g_object_set(pay, "config-interval", 1, "pt", 96, "ssrc", params.ssrc, NULL);
    g_object_set(udpsink, "host", params.rtp_host.c_str(), "port", params.rtp_port, "sync", FALSE, NULL);

    addAndSync(stream_bin, pay);
    addAndSync(stream_bin, udpsink);

    gst_element_link_many(q_rtp, pay, udpsink, NULL);

    LOG_INFO("PipelineBuilder", "[%s] RTP branch created (shared encoder)", stream_id.c_str());
}

// ============================================================================
// Record Branch (for encoded video): tee -> VideoRecorder bin
// ============================================================================

void DeepStreamPipelineBuilder::createRecordBranch(GstElement* stream_bin,
                                                    const std::string& stream_id,
                                                    GstElement* tee)
{
    VideoRecorder* recorder = (VideoRecorder*)g_object_get_data(G_OBJECT(stream_bin), "recorder");
    if (!recorder) return;

    LOG_INFO("PipelineBuilder", "[%s] Creating record branch", stream_id.c_str());

    GstElement* record_bin = recorder->createRecordBin();
    if (!record_bin) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create record bin", stream_id.c_str());
        return;
    }

    addAndSync(stream_bin, record_bin);
    
    GstPad* tee_src = gst_element_request_pad_simple(tee, "src_%u");
    GstPad* rec_sink = gst_element_get_static_pad(record_bin, "sink");
    
    GstPadLinkReturn ret = gst_pad_link(tee_src, rec_sink);
    gst_object_unref(rec_sink);
    
    if (ret != GST_PAD_LINK_OK) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to link tee -> record: %s", 
                 stream_id.c_str(), padLinkResultStr(ret));
    } else {
        LOG_INFO("PipelineBuilder", "[%s] Record branch created", stream_id.c_str());
    }
}

// ============================================================================
// Record Branch from H264 tee: tee -> queue -> VideoRecorder bin
// ============================================================================

void DeepStreamPipelineBuilder::createRecordBranchFromH264(GstElement* stream_bin,
                                                            const std::string& stream_id,
                                                            GstElement* tee_h264,
                                                            VideoRecorder* recorder)
{
    if (!recorder) return;

    LOG_INFO("PipelineBuilder", "[%s] Creating record branch from shared encoder", stream_id.c_str());

    GstElement* q_rec = linkTeeToQueue(stream_bin, tee_h264, "q_rec_" + stream_id, 200, false);
    if (!q_rec) return;

    GstElement* record_bin = recorder->createRecordBin();
    if (!record_bin) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to create record bin", stream_id.c_str());
        return;
    }

    addAndSync(stream_bin, record_bin);
    
    GstPad* q_src = gst_element_get_static_pad(q_rec, "src");
    GstPad* rec_sink = gst_element_get_static_pad(record_bin, "sink");
    
    GstPadLinkReturn ret = gst_pad_link(q_src, rec_sink);
    gst_object_unref(q_src);
    gst_object_unref(rec_sink);
    
    if (ret != GST_PAD_LINK_OK) {
        LOG_ERROR("PipelineBuilder", "[%s] Failed to link queue -> record: %s", 
                 stream_id.c_str(), padLinkResultStr(ret));
    } else {
        LOG_INFO("PipelineBuilder", "[%s] Record branch created (shared encoder)", stream_id.c_str());
    }
}
