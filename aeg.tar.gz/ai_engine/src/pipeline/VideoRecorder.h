#pragma once
#include <gst/gst.h>
#include <string>
#include <memory>
#include <vector>
#include <mutex>
#include "../aws/S3Uploader.h"

/**
 * VideoRecorder - Creates recording pipeline bin and handles S3 upload
 */
class VideoRecorder {
public:
    VideoRecorder(const std::string& stream_id, 
                  const std::string& output_dir,
                  std::shared_ptr<S3Uploader> s3 = nullptr);
    ~VideoRecorder();

    // Create the record bin (queue -> h264parse -> splitmuxsink)
    // Returns a bin with ghost sink pad "sink"
    GstElement* createRecordBin();
    
    // Called when a segment is ready (by splitmuxsink signal)
    void onSegmentReady(const std::string& local_path);
    
    // Append metadata JSON for current segment
    void appendMetadata(const std::string& json);
    
    // Settings
    void setRemoveAfterUpload(bool remove) { remove_after_upload_ = remove; }
    void setSegmentDuration(uint64_t seconds) { segment_duration_sec_ = seconds; }

private:
    std::string stream_id_;
    std::string output_dir_;
    std::shared_ptr<S3Uploader> s3_;
    
    bool remove_after_upload_ = true;
    uint64_t segment_duration_sec_ = 10;
    
    // Metadata buffer
    std::vector<std::string> metadata_buffer_;
    std::mutex metadata_mutex_;
    
    // Save metadata to JSON file
    void saveMetadata(const std::string& video_path);
};
