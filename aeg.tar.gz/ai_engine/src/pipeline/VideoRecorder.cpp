#include "VideoRecorder.h"
#include "util/Logger.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <sstream>

namespace fs = std::filesystem;

VideoRecorder::VideoRecorder(const std::string& stream_id,
                             const std::string& output_dir,
                             std::shared_ptr<S3Uploader> s3)
    : stream_id_(stream_id), output_dir_(output_dir), s3_(s3)
{
    // Create output directory if not exists
    fs::create_directories(output_dir_);
    LOG_INFO("VideoRecorder", "[%s] Created, output: %s", stream_id_.c_str(), output_dir_.c_str());
}

VideoRecorder::~VideoRecorder()
{
    LOG_INFO("VideoRecorder", "[%s] Destroyed", stream_id_.c_str());
}

GstElement* VideoRecorder::createRecordBin()
{
    std::string bin_name = "record_bin_" + stream_id_;
    GstElement* bin = gst_bin_new(bin_name.c_str());
    if (!bin) {
        LOG_ERROR("VideoRecorder", "[%s] Failed to create bin", stream_id_.c_str());
        return nullptr;
    }

    // Create elements
    GstElement* queue = gst_element_factory_make("queue", ("q_rec_" + stream_id_).c_str());
    GstElement* parse = gst_element_factory_make("h264parse", ("h264parse_rec_" + stream_id_).c_str());
    GstElement* mux = gst_element_factory_make("splitmuxsink", ("splitmux_" + stream_id_).c_str());
    GstElement* qtmux = gst_element_factory_make("qtmux", ("qtmux_" + stream_id_).c_str());

    if (!queue || !parse || !mux || !qtmux) {
        LOG_ERROR("VideoRecorder", "[%s] Failed to create recording elements", stream_id_.c_str());
        if (queue) gst_object_unref(queue);
        if (parse) gst_object_unref(parse);
        if (mux) gst_object_unref(mux);
        if (qtmux) gst_object_unref(qtmux);
        gst_object_unref(bin);
        return nullptr;
    }

    // Configure queue
    g_object_set(queue, "max-size-buffers", 200, NULL);

    // Configure splitmuxsink
    std::string location = output_dir_ + "/" + stream_id_ + "_%05d.mp4";
    g_object_set(mux,
                 "location", location.c_str(),
                 "max-size-time", (guint64)(segment_duration_sec_ * GST_SECOND),
                 "muxer", qtmux,
                 NULL);

    // Add elements to bin
    gst_bin_add_many(GST_BIN(bin), queue, parse, mux, NULL);

    // Link: queue -> parse -> mux
    if (!gst_element_link_many(queue, parse, mux, NULL)) {
        LOG_ERROR("VideoRecorder", "[%s] Failed to link recording chain", stream_id_.c_str());
        gst_object_unref(bin);
        return nullptr;
    }

    // Create ghost pad for sink
    GstPad* queue_sink = gst_element_get_static_pad(queue, "sink");
    GstPad* ghost = gst_ghost_pad_new("sink", queue_sink);
    gst_element_add_pad(bin, ghost);
    gst_object_unref(queue_sink);

    // Connect format-location-full signal for segment completion callback
    g_object_set_data(G_OBJECT(mux), "recorder", this);
    g_signal_connect(mux, "format-location-full",
        G_CALLBACK(+[](GstElement* splitmux, guint fragment_id, 
                       GstSample* first_sample, gpointer user_data) -> gchar* {
            auto* recorder = static_cast<VideoRecorder*>(
                g_object_get_data(G_OBJECT(splitmux), "recorder"));
            
            gchar* location = nullptr;
            g_object_get(splitmux, "location", &location, NULL);
            
            if (location && recorder) {
                gchar* actual_file = g_strdup_printf(location, fragment_id);
                
                // Previous segment is now complete - process it
                if (fragment_id > 0) {
                    gchar* prev_file = g_strdup_printf(location, fragment_id - 1);
                    recorder->onSegmentReady(std::string(prev_file));
                    g_free(prev_file);
                }
                
                g_free(location);
                return actual_file;
            }
            
            return location;
        }), nullptr);

    LOG_INFO("VideoRecorder", "[%s] Record bin created -> %s", stream_id_.c_str(), location.c_str());
    return bin;
}

void VideoRecorder::appendMetadata(const std::string& json)
{
    std::lock_guard<std::mutex> lock(metadata_mutex_);
    metadata_buffer_.push_back(json);
}

void VideoRecorder::saveMetadata(const std::string& video_path)
{
    std::vector<std::string> metadata_copy;
    {
        std::lock_guard<std::mutex> lock(metadata_mutex_);
        metadata_copy = std::move(metadata_buffer_);
        metadata_buffer_.clear();
    }
    
    if (metadata_copy.empty()) {
        LOG_INFO("VideoRecorder", "[%s] No metadata for segment", stream_id_.c_str());
        return;
    }

    // Generate metadata filename (same as video but .json)
    fs::path video_file(video_path);
    std::string metadata_path = video_file.parent_path().string() + "/" + 
                                video_file.stem().string() + ".json";
    
    std::ofstream file(metadata_path);
    if (!file.is_open()) {
        LOG_ERROR("VideoRecorder", "[%s] Cannot create metadata file: %s", 
                  stream_id_.c_str(), metadata_path.c_str());
        return;
    }
    
    file << "[\n";
    for (size_t i = 0; i < metadata_copy.size(); ++i) {
        file << "  " << metadata_copy[i];
        if (i < metadata_copy.size() - 1) file << ",";
        file << "\n";
    }
    file << "]\n";
    file.close();
    
    LOG_INFO("VideoRecorder", "[%s] Saved metadata: %s (%zu items)", 
             stream_id_.c_str(), metadata_path.c_str(), metadata_copy.size());
}

void VideoRecorder::onSegmentReady(const std::string& local_path)
{
    LOG_INFO("VideoRecorder", "[%s] Segment ready: %s", stream_id_.c_str(), local_path.c_str());
    
    fs::path video_file(local_path);
    if (!fs::exists(video_file)) {
        LOG_WARN("VideoRecorder", "[%s] Video file not found: %s", stream_id_.c_str(), local_path.c_str());
        return;
    }

    // Save metadata JSON
    saveMetadata(local_path);
    
    // Generate timestamp-based filename for S3
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    std::tm tm;
    localtime_r(&time_t, &tm);
    
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y%m%d_%H%M%S");
    std::string timestamp = oss.str();
    
    std::string video_s3_name = timestamp + ".mp4";
    std::string metadata_s3_name = timestamp + ".json";
    std::string metadata_path = video_file.parent_path().string() + "/" + 
                                video_file.stem().string() + ".json";

    // Upload to S3
    if (s3_) {
        std::string s3_prefix = "streams/" + stream_id_ + "/";
        
        bool video_ok = s3_->uploadFile(local_path, s3_prefix + video_s3_name);
        bool metadata_ok = true;
        
        if (fs::exists(metadata_path)) {
            metadata_ok = s3_->uploadFile(metadata_path, s3_prefix + metadata_s3_name);
        }
        
        if (video_ok) {
            LOG_INFO("VideoRecorder", "[%s] Uploaded: %s", stream_id_.c_str(), video_s3_name.c_str());
        }
        
        // Delete local files after successful upload
        if (remove_after_upload_ && video_ok && metadata_ok) {
            std::error_code ec;
            fs::remove(local_path, ec);
            if (fs::exists(metadata_path)) {
                fs::remove(metadata_path, ec);
            }
            LOG_INFO("VideoRecorder", "[%s] Deleted local files", stream_id_.c_str());
        }
    }
}
