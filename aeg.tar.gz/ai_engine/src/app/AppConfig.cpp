#include "AppConfig.h"
#include <nlohmann/json.hpp>
#include <fstream>

AppConfig AppConfig::load(const std::string &path)
{
    std::ifstream f(path);
    nlohmann::json j = nlohmann::json::parse(f);

    AppConfig cfg;
    
    // DeepStream Inference Configuration
    cfg.inferConfigPath = j.value("inferConfigPath", "infer_data/config_infer_primary_yolo11.txt");
    cfg.maxStreams = j.value("maxStreams", 4);

    // S3 Configuration
    cfg.s3Bucket = j.value("s3Bucket", "my-bucket");
    cfg.s3Region = j.value("s3Region", "us-east-1");
    cfg.s3Endpoint = j.value("s3Endpoint", ""); // Empty = use AWS S3
    cfg.s3AccessKey = j.value("s3AccessKey", "");
    cfg.s3SecretKey = j.value("s3SecretKey", "");
    cfg.s3RoleArn = j.value("s3RoleArn", ""); // Optional: for cross-account access
    cfg.enableS3 = j.value("enableS3", false);

    // RTP output to mediasoup (defaults)
    cfg.rtpHost = j.value("rtpHost", "127.0.0.1");

    // HTTP Server Port (defaults)
    cfg.httpPort = j.value("httpPort", 7879);

    // Metadata WebSocket URL (defaults)
    cfg.metadataWSUrl = j.value("metadataWSUrl", "ws://127.0.0.1:9002/metadata");

    // Mediasoup server HTTP endpoint (defaults)
    cfg.mediasoupServerUrl = j.value("mediasoupServerUrl", "http://127.0.0.1:3000");

    // Recording Configuration
    cfg.outputDir = j.value("outputDir", "/workspace/recordings");
    cfg.segmentDurationSec = j.value("segmentDurationSec", 10);
    
    // Reconnection Configuration
    cfg.reconnectIntervalMs = j.value("reconnectIntervalMs", 5000);
    cfg.maxReconnectAttempts = j.value("maxReconnectAttempts", 0);

    // Logging Configuration
    cfg.logLevel = j.value("logLevel", "info");
    cfg.gstLogLevel = j.value("gstLogLevel", "warning");

    return cfg;
}
