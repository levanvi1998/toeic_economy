#pragma once
#include <string>

struct AppConfig
{
    // DeepStream Inference Configuration
    std::string inferConfigPath;
    int maxStreams;

    // S3 Configuration
    std::string s3Bucket;
    std::string s3Region;
    std::string s3Endpoint; // Optional: for S3-compatible storage (e.g., MinIO)
    std::string s3AccessKey;
    std::string s3SecretKey;
    std::string s3RoleArn; // Optional: for cross-account S3 access via assume role
    bool enableS3;

    // RTP output to mediasoup
    std::string rtpHost; // Mediasoup RTP endpoint host

    // HTTP Server Port
    int httpPort; // Port for HTTP API server

    // Metadata WebSocket to uWebSockets.js
    std::string metadataWSUrl; // WebSocket URL for metadata (e.g., "ws://localhost:9002/metadata")

    // Mediasoup server HTTP endpoint
    std::string mediasoupServerUrl; // HTTP URL for mediasoup API (e.g., "http://localhost:3000")

    // Recording Configuration
    std::string outputDir;
    int segmentDurationSec;
    
    // Reconnection Configuration
    int reconnectIntervalMs;
    int maxReconnectAttempts;

    // Logging Configuration
    std::string logLevel;    // Application log level: fatal, error, warn, info, debug, verbose
    std::string gstLogLevel; // GStreamer log level: 0-9 or none, error, warning, fixme, info, debug, log, trace, memdump

    static AppConfig load(const std::string &path);
};
