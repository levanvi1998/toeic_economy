#pragma once
#include <string>
#include <mutex>
#include <unordered_map>
#include <vector>

class S3Uploader {
public:
    S3Uploader(const std::string& bucket,
               const std::string& region,
               const std::string& endpoint,
               const std::string& accessKey,
               const std::string& secretKey,
               const std::string& roleArn = "",
               bool enableAws = true);
    ~S3Uploader();

    // Upload local file to S3 key. Returns true if success (or file exists and uploaded).
    bool uploadFile(const std::string& localPath, const std::string& s3Key);
    
    // Upload string content directly to S3 key
    bool uploadString(const std::string& content, const std::string& s3Key);

    // Append metadata to buffer for a stream
    void appendMetadata(const std::string& streamId, const std::string& metadata_json);

    // Flush metadata buffer to local file and optionally upload to S3
    bool flushMetadata(const std::string& streamId, bool upload = true);

    // Flush all streams' metadata
    void flushAllMetadata();

private:
    std::string bucket_;
    std::string region_;
    std::string endpoint_;
    std::string accessKey_;
    std::string secretKey_;
    std::string roleArn_;
    bool enabledAws_;
    std::mutex mux_;

    // Per-stream metadata buffer
    std::unordered_map<std::string, std::vector<std::string>> metadata_buffers_;
    std::mutex metadata_mux_;

    // internal AWS client pointer hidden to avoid header leak (pimpl-like)
    struct Impl;
    Impl* impl_ = nullptr;
};
