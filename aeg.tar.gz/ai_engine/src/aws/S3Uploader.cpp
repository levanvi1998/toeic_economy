#include "S3Uploader.h"
#include "util/Logger.h"
#include <iostream>
#include <filesystem>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <sstream>

#ifdef USE_AWS_SDK
#include <aws/core/Aws.h>
#include <aws/core/auth/AWSCredentials.h>
#include <aws/s3/S3Client.h>
#include <aws/s3/model/PutObjectRequest.h>
#include <aws/sts/STSClient.h>
#include <aws/sts/model/AssumeRoleRequest.h>
#endif

struct S3Uploader::Impl
{
#ifdef USE_AWS_SDK
    std::shared_ptr<Aws::S3::S3Client> client;
#endif
};

S3Uploader::S3Uploader(const std::string &bucket,
                       const std::string &region,
                       const std::string &endpoint,
                       const std::string &accessKey,
                       const std::string &secretKey,
                       const std::string &roleArn,
                       bool enableAws)
    : bucket_(bucket), region_(region), endpoint_(endpoint),
      accessKey_(accessKey), secretKey_(secretKey), roleArn_(roleArn), enabledAws_(enableAws)
{
    impl_ = new Impl();
#ifdef USE_AWS_SDK
    if (enabledAws_)
    {
        Aws::SDKOptions options;
        Aws::InitAPI(options);

        Aws::Client::ClientConfiguration config;
        config.region = region_;

        // Set custom endpoint if provided (for S3-compatible storage like MinIO)
        if (!endpoint_.empty())
        {
            config.endpointOverride = endpoint_;
            config.scheme = Aws::Http::Scheme::HTTP; // Use HTTP for local MinIO
            config.verifySSL = false;
            LOG_INFO("S3Uploader", "Using custom endpoint: %s", endpoint_.c_str());
        }

        // Choose credential strategy
        if (!roleArn_.empty())
        {
            // Option 3: Assume role for cross-account access
            LOG_INFO("S3Uploader", "Attempting to assume role: %s", roleArn_.c_str());

            Aws::STS::STSClient sts_client(config);
            Aws::STS::Model::AssumeRoleRequest sts_request;
            sts_request.SetRoleArn(roleArn_);
            sts_request.SetRoleSessionName("StreamManager-" + std::to_string(std::time(nullptr)));
            sts_request.SetDurationSeconds(3600); // 1 hour

            auto sts_outcome = sts_client.AssumeRole(sts_request);
            if (sts_outcome.IsSuccess())
            {
                const auto& credentials = sts_outcome.GetResult().GetCredentials();
                Aws::Auth::AWSCredentials assumed_creds(
                    credentials.GetAccessKeyId(),
                    credentials.GetSecretAccessKey(),
                    credentials.GetSessionToken()
                );

                impl_->client = std::make_shared<Aws::S3::S3Client>(
                    assumed_creds,
                    config,
                    Aws::Client::AWSAuthV4Signer::PayloadSigningPolicy::Never,
                    !endpoint_.empty()
                );
                LOG_INFO("S3Uploader", "Successfully assumed role for cross-account access");
            }
            else
            {
                LOG_ERROR("S3Uploader", "Failed to assume role: %s", sts_outcome.GetError().GetMessage().c_str());
                enabledAws_ = false;
                return;
            }
        }
        else if (!accessKey_.empty() && !secretKey_.empty())
        {
            // Option 1: Use explicit credentials from config
            Aws::Auth::AWSCredentials credentials(accessKey_, secretKey_);
            impl_->client = std::make_shared<Aws::S3::S3Client>(
                credentials,
                config,
                Aws::Client::AWSAuthV4Signer::PayloadSigningPolicy::Never,
                !endpoint_.empty() // virtualAddressing = false for custom endpoint
            );
            LOG_INFO("S3Uploader", "Using explicit credentials from config");
        }
        else
        {
            // Option 2: Use default credential provider chain (IAM role, env vars, ~/.aws/credentials)
            impl_->client = std::make_shared<Aws::S3::S3Client>(
                config,
                Aws::Client::AWSAuthV4Signer::PayloadSigningPolicy::Never,
                !endpoint_.empty() // virtualAddressing = false for custom endpoint
            );
            LOG_INFO("S3Uploader", "Using default credential provider (IAM role / environment / credentials file)");
        }

        LOG_INFO("S3Uploader", "AWS SDK initialized region=%s bucket=%s", region_.c_str(), bucket_.c_str());
    }
#else
    if (enabledAws_)
    {
        LOG_ERROR("S3Uploader", "Compiled without AWS SDK - fallback to disabled");
        enabledAws_ = false;
    }
#endif
}

S3Uploader::~S3Uploader()
{
#ifdef USE_AWS_SDK
    if (enabledAws_)
    {
        Aws::SDKOptions options;
        Aws::ShutdownAPI(options);
    }
#endif
    delete impl_;
}

bool S3Uploader::uploadFile(const std::string &localPath, const std::string &s3Key)
{
    std::lock_guard<std::mutex> lk(mux_);
    if (!std::filesystem::exists(localPath))
    {
        LOG_ERROR("S3Uploader", "Local file not found: %s", localPath.c_str());
        return false;
    }

    if (!enabledAws_)
    {
        // Fallback: print and return false (or true if you want)
        LOG_INFO("S3Uploader", "AWS disabled — would upload %s -> %s", localPath.c_str(), s3Key.c_str());
        return false;
    }

#ifdef USE_AWS_SDK
    Aws::S3::Model::PutObjectRequest request;
    request.SetBucket(bucket_.c_str());
    request.SetKey(s3Key.c_str());

    auto input_data = Aws::MakeShared<Aws::FStream>("PutObjectInputStream", localPath.c_str(), std::ios::in | std::ios::binary);
    request.SetBody(input_data);

    auto outcome = impl_->client->PutObject(request);
    if (!outcome.IsSuccess())
    {
        LOG_ERROR("S3Uploader", "PutObject failed: %s", outcome.GetError().GetMessage().c_str());
        return false;
    }
    return true;
#else
    return false;
#endif
}

bool S3Uploader::uploadString(const std::string &content, const std::string &s3Key)
{
    std::lock_guard<std::mutex> lk(mux_);
    
    if (!enabledAws_)
    {
        LOG_DEBUG("S3Uploader", "AWS disabled — would upload string to %s", s3Key.c_str());
        return false;
    }

#ifdef USE_AWS_SDK
    Aws::S3::Model::PutObjectRequest request;
    request.SetBucket(bucket_.c_str());
    request.SetKey(s3Key.c_str());
    request.SetContentType("application/json");
    
    auto input_data = Aws::MakeShared<Aws::StringStream>("PutObjectInputStream");
    *input_data << content;
    request.SetBody(input_data);
    
    auto outcome = impl_->client->PutObject(request);
    if (!outcome.IsSuccess())
    {
        LOG_ERROR("S3Uploader", "PutObject (string) failed for %s: %s", 
                 s3Key.c_str(), outcome.GetError().GetMessage().c_str());
        return false;
    }
    
    LOG_DEBUG("S3Uploader", "Uploaded string to s3://%s/%s (%zu bytes)", 
             bucket_.c_str(), s3Key.c_str(), content.size());
    return true;
#else
    return false;
#endif
}

void S3Uploader::appendMetadata(const std::string &streamId, const std::string &metadata_json)
{
    std::lock_guard<std::mutex> lk(metadata_mux_);
    metadata_buffers_[streamId].push_back(metadata_json);

    // Auto-flush every 100 entries to avoid memory buildup
    if (metadata_buffers_[streamId].size() >= 100)
    {
        // Release lock temporarily for flush
        metadata_mux_.unlock();
        flushMetadata(streamId, true);
        metadata_mux_.lock();
    }
}

bool S3Uploader::flushMetadata(const std::string &streamId, bool upload)
{
    std::vector<std::string> buffer;
    {
        std::lock_guard<std::mutex> lk(metadata_mux_);
        auto it = metadata_buffers_.find(streamId);
        if (it == metadata_buffers_.end() || it->second.empty())
        {
            return true; // nothing to flush
        }
        buffer = std::move(it->second);
        metadata_buffers_.erase(it);
    }

    // Create metadata directory
    std::string metadata_dir = "./metadata/" + streamId;
    std::filesystem::create_directories(metadata_dir);

    // Generate timestamped filename
    using namespace std::chrono;
    auto now = system_clock::now();
    auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
    std::time_t t = system_clock::to_time_t(now);
    std::tm tm;

    localtime_r(&t, &tm);

    std::ostringstream ss;
    ss << metadata_dir << "/" << streamId << "_"
       << std::put_time(&tm, "%Y%m%d_%H%M%S") << '_'
       << std::setfill('0') << std::setw(3) << ms.count() << ".jsonl";
    std::string local_path = ss.str();

    // Write to file (JSONL format - one JSON per line)
    std::ofstream ofs(local_path, std::ios::app);
    if (!ofs.is_open())
    {
        LOG_ERROR("S3Uploader", "Failed to open metadata file: %s", local_path.c_str());
        return false;
    }

    for (const auto &meta : buffer)
    {
        ofs << meta << "\n";
    }
    ofs.close();

    LOG_INFO("S3Uploader", "Flushed %zu metadata entries to %s", buffer.size(), local_path.c_str());

    // Upload to S3 if enabled
    if (upload)
    {
        std::string s3_key = "metadata/" + streamId + "/" +
                             std::filesystem::path(local_path).filename().string();
        return uploadFile(local_path, s3_key);
    }

    return true;
}

void S3Uploader::flushAllMetadata()
{
    std::vector<std::string> stream_ids;
    {
        std::lock_guard<std::mutex> lk(metadata_mux_);
        for (const auto &pair : metadata_buffers_)
        {
            stream_ids.push_back(pair.first);
        }
    }

    for (const auto &stream_id : stream_ids)
    {
        flushMetadata(stream_id, true);
    }
}
